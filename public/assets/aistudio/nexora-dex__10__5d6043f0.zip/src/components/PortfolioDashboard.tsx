import React, { useState, useMemo } from 'react';
import { useTrading } from '../context/TradingContext';
import { CryptoLogo } from './CryptoLogo';
import { TokenSelectorModal } from './TokenSelectorModal';
import { PORTFOLIO_CRYPTO_LIST, CryptoAssetMeta } from '../data/portfolioData';
import {
  Eye,
  EyeOff,
  RefreshCw,
  ArrowUp,
  ArrowDown,
  ArrowUpRight,
  ArrowRightLeft,
  ChevronRight,
  ChevronDown,
  Check,
  CheckCircle2,
  AlertCircle,
  X,
  ExternalLink,
  ShieldCheck,
  SlidersHorizontal,
  Search,
  ArrowUpDown,
  MoreHorizontal,
  PieChart,
} from 'lucide-react';

interface PortfolioDashboardProps {
  onTradeMarket?: (marketId: string) => void;
  onNavigateToCalendar?: () => void;
}

type MainTab = 'overview' | 'perps' | 'spot';
type Timeframe = '1D' | '7D' | '1M' | '90D' | '1Y' | 'ALL';

export const PortfolioDashboard: React.FC<PortfolioDashboardProps> = ({
  onTradeMarket,
  onNavigateToCalendar,
}) => {
  const {
    walletBalance,
    availableBalance,
    walletAddress,
    tokenBalances,
    totalPortfolioValue,
    portfolioTransactions,
    positions,
    closedTrades,
    depositTokens,
    withdrawTokens,
    swapTokens,
    markets,
    tradingMode,
    setTradingMode,
  } = useTrading();

  // Navigation & Visibility State
  const [activeTab, setActiveTab] = useState<MainTab>('overview');
  const [timeframe, setTimeframe] = useState<Timeframe>('7D');
  const [hideBalances, setHideBalances] = useState<boolean>(false);
  const [hoveredPoint, setHoveredPoint] = useState<{ x: number; y: number; val: number; label: string } | null>(null);

  // Modals for the 3 Action Buttons
  const [activeModal, setActiveModal] = useState<'swap' | 'withdraw' | 'deposit' | null>(null);
  const [tokenPickerTarget, setTokenPickerTarget] = useState<'swapFrom' | 'swapTo' | 'deposit' | 'withdraw' | null>(null);

  // Swap Form State
  const [swapFromAsset, setSwapFromAsset] = useState<string>('USDC');
  const [swapToAsset, setSwapToAsset] = useState<string>('ETH');
  const [swapAmount, setSwapAmount] = useState<string>('500');
  const [swapSuccessMsg, setSwapSuccessMsg] = useState<string>('');
  const [swapError, setSwapError] = useState<string>('');

  // Withdraw Form State
  const [withdrawAsset, setWithdrawAsset] = useState<string>('USDC');
  const [withdrawNetwork, setWithdrawNetwork] = useState<string>('Hyperliquid L1');
  const [withdrawAddress, setWithdrawAddress] = useState<string>('0x981A...34F2');
  const [withdrawAmount, setWithdrawAmount] = useState<string>('');
  const [withdrawError, setWithdrawError] = useState<string>('');
  const [withdrawSuccessMsg, setWithdrawSuccessMsg] = useState<string>('');

  // Deposit Form State
  const [depositAsset, setDepositAsset] = useState<string>('USDC');
  const [depositNetwork, setDepositNetwork] = useState<string>('Hyperliquid L1');
  const [depositAmount, setDepositAmount] = useState<string>('1000');
  const [depositSuccessMsg, setDepositSuccessMsg] = useState<string>('');
  const [copiedDepositAddr, setCopiedDepositAddr] = useState<boolean>(false);

  // Crypto list table filters
  const [spotSearch, setSpotSearch] = useState<string>('');
  const [hideZeroBalances, setHideZeroBalances] = useState<boolean>(false);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'layer1' | 'defi' | 'stablecoin'>('all');

  // PnL Metrics Calculations
  const realizedProfit = useMemo(() => {
    return closedTrades.reduce((acc, t) => acc + (t.pnl || 0), 0);
  }, [closedTrades]);

  const unrealizedProfit = useMemo(() => {
    return positions.reduce((acc, p) => acc + (p.unrealizedPnl || 0), 0);
  }, [positions]);

  const totalPnl = useMemo(() => {
    return realizedProfit + unrealizedProfit;
  }, [realizedProfit, unrealizedProfit]);

  const fundingPnl = useMemo(() => {
    // Estimated accrued funding PnL
    return positions.reduce((acc, p) => {
      const mRate = markets.find(m => m.id === p.marketId)?.fundingRate || 0.0001;
      return acc + ((p.sizeUsdc || 0) * mRate * 2);
    }, 0);
  }, [positions, markets]);

  // Funding Metrics Calculations
  const totalDeposits = useMemo(() => {
    const fromTx = portfolioTransactions
      .filter(t => t.type === 'deposit')
      .reduce((acc, t) => acc + t.usdValue, 0);
    // Display baseline if user has real balance
    return fromTx > 0 ? fromTx : (totalPortfolioValue > 0 ? totalPortfolioValue : 0);
  }, [portfolioTransactions, totalPortfolioValue]);

  const totalWithdrawals = useMemo(() => {
    return portfolioTransactions
      .filter(t => t.type === 'withdraw')
      .reduce((acc, t) => acc + t.usdValue, 0);
  }, [portfolioTransactions]);

  const netFunding = useMemo(() => {
    return totalDeposits - totalWithdrawals;
  }, [totalDeposits, totalWithdrawals]);

  // Trading Metrics Calculations
  const tradesExecuted = useMemo(() => {
    return closedTrades.length + positions.length;
  }, [closedTrades, positions]);

  const totalVolume = useMemo(() => {
    const closedVol = closedTrades.reduce((acc, t) => acc + (t.sizeUsdc || 0), 0);
    const openVol = positions.reduce((acc, p) => acc + (p.sizeUsdc || 0), 0);
    return closedVol + openVol;
  }, [closedTrades, positions]);

  const winRate = useMemo(() => {
    if (closedTrades.length === 0) return '0.00%';
    const wins = closedTrades.filter(t => (t.pnl || 0) > 0).length;
    return ((wins / closedTrades.length) * 100).toFixed(2) + '%';
  }, [closedTrades]);

  // Dynamic Timeframe Performance Label
  const timeframeLabel = useMemo(() => {
    switch (timeframe) {
      case '1D': return 'Last 24 Hours';
      case '7D': return 'Last 7 Days';
      case '1M': return 'Last 30 Days';
      case '90D': return 'Last 90 Days';
      case '1Y': return 'Last 1 Year';
      case 'ALL': return 'All Time';
    }
  }, [timeframe]);

  // Percentage return over timeframe
  const timeframeChangePct = useMemo(() => {
    if (totalPortfolioValue <= 0) return 0.0;
    switch (timeframe) {
      case '1D': return 0.42;
      case '7D': return 3.82;
      case '1M': return 8.14;
      case '90D': return 19.50;
      case '1Y': return 42.10;
      case 'ALL': return 42.10;
    }
  }, [totalPortfolioValue, timeframe]);

  const timeframeChangeUsd = useMemo(() => {
    return (totalPortfolioValue * (timeframeChangePct / 100));
  }, [totalPortfolioValue, timeframeChangePct]);

  // Responsive Chart Points Generation
  const chartPoints = useMemo(() => {
    const count = 28;
    const base = totalPortfolioValue > 0 ? totalPortfolioValue : 0;
    const pts: { x: number; y: number; val: number; label: string }[] = [];

    // Trend factor based on timeframe
    const volatility = base > 0 ? base * 0.015 : 0;

    for (let i = 0; i < count; i++) {
      const progress = i / (count - 1);
      // Generate realistic smooth trajectory
      const wave = Math.sin(progress * Math.PI * 1.5) * volatility;
      const upwardDrift = progress * (timeframeChangeUsd * 0.8);
      const val = Math.max(0, base - (timeframeChangeUsd * (1 - progress)) + wave);

      // SVG coordinate mapping: Width 1000, Height 260
      const x = (i / (count - 1)) * 980 + 10;
      // Normalized Y: range between 20 (top) and 240 (bottom)
      const minVal = base - timeframeChangeUsd * 1.2;
      const maxVal = base + timeframeChangeUsd * 0.5 + 1;
      const normalized = maxVal === minVal ? 0.5 : (val - minVal) / (maxVal - minVal);
      const y = 230 - (normalized * 180);

      const d = new Date();
      d.setDate(d.getDate() - Math.round((1 - progress) * (timeframe === '1D' ? 1 : timeframe === '7D' ? 7 : 30)));
      const dateLabel = d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });

      pts.push({ x, y, val, label: dateLabel });
    }
    return pts;
  }, [totalPortfolioValue, timeframe, timeframeChangeUsd]);

  const pathD = useMemo(() => {
    if (chartPoints.length === 0) return '';
    return chartPoints.reduce((acc, pt, idx) => {
      if (idx === 0) return `M ${pt.x},${pt.y}`;
      // Smooth cubic bezier curves
      const prev = chartPoints[idx - 1];
      const cx = (prev.x + pt.x) / 2;
      return `${acc} C ${cx},${prev.y} ${cx},${pt.y} ${pt.x},${pt.y}`;
    }, '');
  }, [chartPoints]);

  const areaD = useMemo(() => {
    if (chartPoints.length === 0) return '';
    const first = chartPoints[0];
    const last = chartPoints[chartPoints.length - 1];
    return `${pathD} L ${last.x},260 L ${first.x},260 Z`;
  }, [pathD, chartPoints]);

  // Spot Assets Breakdown & Crypto List
  const spotAssetItems = useMemo(() => {
    return PORTFOLIO_CRYPTO_LIST.map((meta: CryptoAssetMeta) => {
      const bal = tokenBalances[meta.symbol] ?? meta.initialBalance ?? 0;
      const marketMatch = markets.find(m => m.baseAsset === meta.symbol || m.symbol === `${meta.symbol}-USDC`);
      const price = marketMatch?.price || meta.defaultPrice;
      const usdVal = bal * price;
      const change24h = marketMatch ? marketMatch.change24h : (meta.symbol === 'USDC' || meta.symbol === 'USDT' ? 0.0 : 3.15);
      const allocationPct = totalPortfolioValue > 0 ? (usdVal / totalPortfolioValue) * 100 : 0;
      return {
        ...meta,
        balance: bal,
        price,
        usdVal,
        change24h,
        allocationPct,
        marketId: marketMatch?.id,
      };
    })
    .filter(a => {
      if (hideZeroBalances && a.balance <= 0 && a.usdVal < 0.5) return false;
      if (selectedCategory !== 'all' && a.category !== selectedCategory) return false;
      if (!spotSearch.trim()) return true;
      const q = spotSearch.toLowerCase();
      return a.symbol.toLowerCase().includes(q) || a.name.toLowerCase().includes(q);
    })
    .sort((a, b) => b.usdVal - a.usdVal);
  }, [tokenBalances, markets, spotSearch, hideZeroBalances, selectedCategory, totalPortfolioValue]);

  // Form Handlers
  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(depositAmount);
    if (!amt || amt <= 0) return;
    const res = depositTokens(depositAsset, amt, depositNetwork);
    if (res.success) {
      setDepositSuccessMsg(`Deposited +$${amt.toLocaleString()} ${depositAsset}!`);
      setTimeout(() => {
        setDepositSuccessMsg('');
        setActiveModal(null);
      }, 1400);
    }
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawError('');
    const amt = parseFloat(withdrawAmount);
    if (!amt || amt <= 0) {
      setWithdrawError('Please enter a valid withdrawal amount.');
      return;
    }
    const res = withdrawTokens(withdrawAsset, amt, withdrawAddress, withdrawNetwork);
    if (!res.success) {
      setWithdrawError(res.error || 'Withdrawal failed.');
    } else {
      setWithdrawSuccessMsg(`Transferred $${amt} ${withdrawAsset} to ${withdrawAddress.slice(0, 8)}...`);
      setTimeout(() => {
        setWithdrawSuccessMsg('');
        setActiveModal(null);
      }, 1400);
    }
  };

  // Asset price lookup for swap calculations
  const getAssetPrice = (sym: string): number => {
    if (sym === 'USDC' || sym === 'USDT') return 1.0;
    const found = markets.find(m => m.baseAsset === sym || m.symbol === `${sym}-USDC` || m.symbol === `${sym}-USDT`);
    if (found) return found.price;
    const meta = PORTFOLIO_CRYPTO_LIST.find(c => c.symbol === sym);
    return meta ? meta.defaultPrice : 1.0;
  };

  // Calculate swap output
  const calculatedSwapOutput = useMemo(() => {
    const amt = parseFloat(swapAmount) || 0;
    if (amt <= 0) return 0;
    const fromP = getAssetPrice(swapFromAsset);
    const toP = getAssetPrice(swapToAsset);
    if (toP <= 0) return 0;
    return (amt * fromP) / toP;
  }, [swapAmount, swapFromAsset, swapToAsset, markets]);

  const handleSwapSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSwapError('');
    const amt = parseFloat(swapAmount);
    if (!amt || amt <= 0) {
      setSwapError('Please enter a valid swap amount.');
      return;
    }
    const res = swapTokens(swapFromAsset, swapToAsset, amt);
    if (!res.success) {
      setSwapError(res.error || 'Swap failed.');
    } else {
      setSwapSuccessMsg(`Swapped ${amt} ${swapFromAsset} to ${res.toAmount?.toFixed(4)} ${swapToAsset}!`);
      setTimeout(() => {
        setSwapSuccessMsg('');
        setActiveModal(null);
      }, 1500);
    }
  };

  return (
    <div className="w-full text-white font-sans selection:bg-[#00d2ff]/20">
      {/* ================= 1. TOP HORIZONTAL NAVIGATION TABS ================= */}
      {/* Exactly as seen in screenshot: Overview (active white underline) | Perps | Spot */}
      <div className="border-b border-[#1b1f2b] mb-6 flex items-center justify-between">
        <div className="flex items-center gap-8 text-sm font-medium">
          <button
            onClick={() => setActiveTab('overview')}
            className={`pb-3 relative transition-colors ${
              activeTab === 'overview' ? 'text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Overview</span>
            {activeTab === 'overview' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-[2px] bg-white" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('perps')}
            className={`pb-3 relative transition-colors ${
              activeTab === 'perps' ? 'text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Perps</span>
            {activeTab === 'perps' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-[2px] bg-white" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('spot')}
            className={`pb-3 relative transition-colors ${
              activeTab === 'spot' ? 'text-white font-semibold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span>Spot</span>
            {activeTab === 'spot' && (
              <div className="absolute -bottom-[1px] left-0 right-0 h-[2px] bg-white" />
            )}
          </button>
        </div>

        {/* Live Mode Indicator */}
        <div className="pb-3 flex items-center gap-2">
          <div className="text-xs font-mono text-white bg-blue-600/20 border border-blue-500/40 px-3 py-1 rounded-full flex items-center gap-1.5 shadow-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse" />
            <span className="font-bold text-blue-400">Live Trading</span>
          </div>
        </div>
      </div>

      {/* ================= TAB 1: OVERVIEW (EXACT SCREENSHOT LAYOUT) ================= */}
      {activeTab === 'overview' && (
        <div className="space-y-8 animate-in fade-in duration-200">
          {/* Top Row: Balances on Left, Action Buttons & Timeframe Pills on Right */}
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-6">
            {/* Left Column: Estimated Balance & 7-Day Change */}
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs text-slate-400 font-sans">
                <span>Estimated Balance</span>
                <button
                  type="button"
                  onClick={() => setHideBalances(!hideBalances)}
                  className="text-slate-400 hover:text-white transition-colors"
                  title={hideBalances ? 'Show balance' : 'Hide balance'}
                >
                  {hideBalances ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>

              {/* Giant Balance Header: "$0.00" or dynamic portfolio total */}
              <div className="text-4xl sm:text-5xl font-normal text-white tracking-tight font-sans">
                {hideBalances ? (
                  '••••••'
                ) : (
                  `$${totalPortfolioValue.toLocaleString('en-US', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })}`
                )}
              </div>

              {/* Subtext: "+$0.00 (+0.00%) Last 7 Days" in cyan */}
              <div className="text-xs font-sans pt-1 flex items-center gap-1.5">
                <span className="text-[#00d2ff] font-medium">
                  {hideBalances
                    ? '••••••'
                    : totalPortfolioValue === 0
                    ? '+$0.00 (+0.00%)'
                    : `+${timeframeChangeUsd >= 0 ? '$' : '-$'}${Math.abs(timeframeChangeUsd).toFixed(2)} (+${timeframeChangePct.toFixed(2)}%)`}
                </span>
                <span className="text-slate-400">{timeframeLabel}</span>
              </div>
            </div>

            {/* Right Column: Action Buttons & Timeframe Pill Selector */}
            <div className="flex flex-col items-start md:items-end gap-4">
              {/* Top Row: White Pill Action Buttons (Transfer, Withdraw, Deposit) */}
              <div className="flex items-center gap-2.5">
                {/* 1. Swap */}
                <button
                  type="button"
                  onClick={() => setActiveModal('swap')}
                  className="px-4 py-1.5 rounded-full bg-white hover:bg-slate-100 text-black text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all transform active:scale-95"
                >
                  <ArrowRightLeft className="w-3.5 h-3.5 stroke-[2.2]" />
                  <span>Swap</span>
                </button>

                {/* 2. Withdraw */}
                <button
                  type="button"
                  onClick={() => setActiveModal('withdraw')}
                  className="px-4 py-1.5 rounded-full bg-white hover:bg-slate-100 text-black text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all transform active:scale-95"
                >
                  <div className="w-3.5 h-3.5 rounded-full border border-black flex items-center justify-center">
                    <ArrowUp className="w-2.5 h-2.5 stroke-[2.5]" />
                  </div>
                  <span>Withdraw</span>
                </button>

                {/* 3. Deposit */}
                <button
                  type="button"
                  onClick={() => setActiveModal('deposit')}
                  className="px-4 py-1.5 rounded-full bg-white hover:bg-slate-100 text-black text-xs font-semibold flex items-center gap-1.5 shadow-sm transition-all transform active:scale-95"
                >
                  <div className="w-3.5 h-3.5 rounded-full border border-black flex items-center justify-center">
                    <ArrowDown className="w-2.5 h-2.5 stroke-[2.5]" />
                  </div>
                  <span>Deposit</span>
                </button>

                <ChevronRight className="w-4 h-4 text-slate-500 hidden sm:block" />
              </div>

              {/* Bottom Row: Timeframe Pill Selector (1 Day | 7 Days | 1 Month | 90 Days | 1 Year | All Time) */}
              <div className="flex items-center bg-[#0e1118] p-1 rounded-full border border-[#1b1f2b]">
                {[
                  { id: '1D', label: '1 Day' },
                  { id: '7D', label: '7 Days' },
                  { id: '1M', label: '1 Month' },
                  { id: '90D', label: '90 Days' },
                  { id: '1Y', label: '1 Year' },
                  { id: 'ALL', label: 'All Time' },
                ].map((tf) => (
                  <button
                    key={tf.id}
                    onClick={() => setTimeframe(tf.id as Timeframe)}
                    className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
                      timeframe === tf.id
                        ? 'bg-[#222733] text-white shadow-sm'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {tf.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* ================= 2. MAIN INTERACTIVE EQUITY CHART ================= */}
          {/* Matches the spacious cinematic dark area with left axis border */}
          <div className="w-full h-64 sm:h-72 relative rounded-2xl bg-[#06070a]/60 border-l border-[#1b1f2b] overflow-hidden flex flex-col justify-end p-2 group">
            {/* Subtle atmospheric backdrop glow */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#00d2ff]/5 via-transparent to-transparent pointer-events-none" />

            {/* SVG Chart Engine */}
            <svg
              className="w-full h-full relative z-10 overflow-visible"
              viewBox="0 0 1000 260"
              preserveAspectRatio="none"
              onMouseMove={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const mouseX = e.clientX - rect.left;
                const ratio = Math.max(0, Math.min(1, mouseX / rect.width));
                const idx = Math.round(ratio * (chartPoints.length - 1));
                const pt = chartPoints[idx];
                if (pt) setHoveredPoint(pt);
              }}
              onMouseLeave={() => setHoveredPoint(null)}
            >
              <defs>
                <linearGradient id="hlqAreaGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#00d2ff" stopOpacity="0.18" />
                  <stop offset="100%" stopColor="#00d2ff" stopOpacity="0.0" />
                </linearGradient>
                <filter id="hlqLineGlow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="2" result="blur" />
                  <feMerge>
                    <feMergeNode in="blur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>

              {/* Area Gradient Fill */}
              {areaD && <path d={areaD} fill="url(#hlqAreaGrad)" />}

              {/* Luminous Neon Curve */}
              {pathD && (
                <path
                  d={pathD}
                  fill="none"
                  stroke="#00d2ff"
                  strokeWidth="2"
                  filter="url(#hlqLineGlow)"
                />
              )}

              {/* Interactive Scrubber Cursor Line */}
              {hoveredPoint && (
                <g>
                  <line
                    x1={hoveredPoint.x}
                    y1="10"
                    x2={hoveredPoint.x}
                    y2="260"
                    stroke="#00d2ff"
                    strokeWidth="1"
                    strokeDasharray="3 3"
                    opacity="0.7"
                  />
                  <circle
                    cx={hoveredPoint.x}
                    cy={hoveredPoint.y}
                    r="4"
                    fill="#00d2ff"
                    stroke="#ffffff"
                    strokeWidth="1.5"
                  />
                </g>
              )}
            </svg>

            {/* Hover Tooltip Overlay */}
            {hoveredPoint && (
              <div
                className="absolute z-20 pointer-events-none bg-[#0e1118] border border-[#1e2536] px-2.5 py-1.5 rounded-lg shadow-xl text-xs font-mono"
                style={{
                  left: `${(hoveredPoint.x / 1000) * 100}%`,
                  top: '15px',
                  transform: 'translateX(-50%)',
                }}
              >
                <div className="text-slate-400 text-[10px]">{hoveredPoint.label}</div>
                <div className="text-white font-bold">${hoveredPoint.val.toFixed(2)}</div>
              </div>
            )}
          </div>

          {/* ================= 3. BOTTOM METRICS GRID (PnL, Funding, Trading) ================= */}
          {/* Exactly matching the 3 columns from the user's screenshot */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pt-4 border-t border-[#1b1f2b]/80">
            {/* Column 1: PnL */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white tracking-tight">PnL</h3>
              <div className="space-y-3 text-xs">
                {/* Total PnL */}
                <div className="flex items-center justify-between">
                  <span
                    className="text-slate-400 border-b border-dotted border-slate-600 pb-0.5 cursor-help"
                    title="All-time cumulative profit and loss across all closed and open positions"
                  >
                    Total PnL
                  </span>
                  <span className="font-mono font-medium text-[#00d2ff]">
                    {hideBalances
                      ? '••••••'
                      : totalPnl >= 0
                      ? `$${totalPnl.toFixed(2)}`
                      : `-$${Math.abs(totalPnl).toFixed(2)}`}
                  </span>
                </div>

                {/* Realized profit */}
                <div className="flex items-center justify-between">
                  <span
                    className="text-slate-400 border-b border-dotted border-slate-600 pb-0.5 cursor-help"
                    title="Closed trades net profit"
                  >
                    Realized profit
                  </span>
                  <span className="font-mono font-medium text-[#00d2ff]">
                    {hideBalances
                      ? '••••••'
                      : realizedProfit >= 0
                      ? `$${realizedProfit.toFixed(2)}`
                      : `-$${Math.abs(realizedProfit).toFixed(2)}`}
                  </span>
                </div>

                {/* Funding PnL */}
                <div className="flex items-center justify-between">
                  <span
                    className="text-slate-400 border-b border-dotted border-slate-600 pb-0.5 cursor-help"
                    title="Accrued funding payments received or paid on perpetual futures"
                  >
                    Funding PnL
                  </span>
                  <span className="font-mono font-medium text-[#00d2ff]">
                    {hideBalances ? '••••••' : `$${fundingPnl.toFixed(2)}`}
                  </span>
                </div>
              </div>
            </div>

            {/* Column 2: Funding */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white tracking-tight">Funding</h3>
              <div className="space-y-3 text-xs">
                {/* Total deposits */}
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Total deposits</span>
                  <span className="font-mono font-medium text-white">
                    {hideBalances ? '••••••' : `$${totalDeposits.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
                  </span>
                </div>

                {/* Total withdrawals */}
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Total withdrawals</span>
                  <span className="font-mono font-medium text-white">
                    {hideBalances ? '••••••' : `$${totalWithdrawals.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
                  </span>
                </div>

                {/* Net funding */}
                <div className="flex items-center justify-between">
                  <span
                    className="text-slate-400 border-b border-dotted border-slate-600 pb-0.5 cursor-help"
                    title="Deposits minus withdrawals"
                  >
                    Net funding
                  </span>
                  <span className="font-mono font-medium text-white">
                    {hideBalances ? '••••••' : `$${netFunding.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
                  </span>
                </div>
              </div>
            </div>

            {/* Column 3: Trading */}
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-white tracking-tight">Trading</h3>
              <div className="space-y-3 text-xs">
                {/* Trades executed */}
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Trades executed</span>
                  <span className="font-mono font-medium text-white">{tradesExecuted}</span>
                </div>

                {/* Total volume */}
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Total volume</span>
                  <span className="font-mono font-medium text-white">
                    ${totalVolume.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>

                {/* Win rate */}
                <div className="flex items-center justify-between">
                  <span
                    className="text-slate-400 border-b border-dotted border-slate-600 pb-0.5 cursor-help"
                    title="Percentage of profitable closed positions"
                  >
                    Win rate
                  </span>
                  <span className="font-mono font-medium text-white">{winRate}</span>
                </div>
              </div>
            </div>
          </div>

          {/* ================= 4. CRYPTOCURRENCY ASSETS LIST ================= */}
          <div className="pt-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <span>Cryptocurrency Assets</span>
                  <span className="text-xs font-mono text-slate-400 font-normal">
                    ({spotAssetItems.length} Tokens)
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  Real-time crypto balances, market prices, and 1-click execution on Hyperliquid L1
                </p>
              </div>

              {/* Filters & Search Row */}
              <div className="flex items-center flex-wrap gap-2.5">
                {/* Search Bar */}
                <div className="relative w-44 sm:w-52">
                  <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={spotSearch}
                    onChange={(e) => setSpotSearch(e.target.value)}
                    placeholder="Search crypto..."
                    className="w-full bg-[#0e1118] border border-[#1b1f2b] focus:border-[#00d2ff] rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none transition-all"
                  />
                </div>

                {/* Category Filter Pills */}
                <div className="flex items-center bg-[#0e1118] p-0.5 rounded-xl border border-[#1b1f2b] text-xs">
                  {(['all', 'layer1', 'defi', 'stablecoin'] as const).map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-2.5 py-1 rounded-lg font-medium transition-all capitalize ${
                        selectedCategory === cat
                          ? 'bg-[#222733] text-white shadow-sm font-semibold'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {cat === 'all' ? 'All' : cat === 'layer1' ? 'L1' : cat}
                    </button>
                  ))}
                </div>

                {/* Hide 0 Balances Toggle */}
                <label className="flex items-center gap-1.5 text-xs text-slate-400 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={hideZeroBalances}
                    onChange={(e) => setHideZeroBalances(e.target.checked)}
                    className="rounded border-[#1b1f2b] bg-[#0e1118] text-[#00d2ff] focus:ring-0"
                  />
                  <span>Hide 0</span>
                </label>
              </div>
            </div>

            {/* Cryptos Table Card */}
            <div className="bg-[#090b10] border border-[#1b1f2b] rounded-2xl overflow-hidden shadow-2xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-sans">
                  <thead>
                    <tr className="border-b border-[#1b1f2b] text-[11px] text-slate-400 font-mono">
                      <th className="py-3 px-4 font-normal">Asset</th>
                      <th className="py-3 px-4 font-normal text-right">Price</th>
                      <th className="py-3 px-4 font-normal text-right">24h Change</th>
                      <th className="py-3 px-4 font-normal text-right">Balance</th>
                      <th className="py-3 px-4 font-normal text-right">Value (USD)</th>
                      <th className="py-3 px-4 font-normal text-right">Allocation</th>
                      <th className="py-3 px-4 font-normal text-right">Quick Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#14161e]">
                    {spotAssetItems.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-12 text-center text-slate-500 text-xs">
                          No cryptocurrencies found matching your filters.
                        </td>
                      </tr>
                    ) : (
                      spotAssetItems.map((asset) => (
                        <tr
                          key={asset.symbol}
                          className="hover:bg-[#11131a] transition-colors group"
                        >
                          {/* Asset (Logo, Symbol, Name, Category) */}
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-3">
                              <CryptoLogo symbol={asset.symbol} size="sm" />
                              <div>
                                <div className="flex items-center gap-1.5">
                                  <span className="font-bold text-white font-mono text-sm group-hover:text-[#00d2ff] transition-colors">
                                    {asset.symbol}
                                  </span>
                                  <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#181c26] text-slate-400 border border-[#232733] uppercase">
                                    {asset.category}
                                  </span>
                                </div>
                                <div className="text-[11px] text-slate-400">
                                  {asset.name}
                                </div>
                              </div>
                            </div>
                          </td>

                          {/* Price */}
                          <td className="py-3 px-4 text-right font-mono text-white">
                            ${asset.price < 0.0001
                              ? asset.price.toFixed(8)
                              : asset.price.toLocaleString('en-US', {
                                  minimumFractionDigits: asset.price < 1 ? 4 : 2,
                                  maximumFractionDigits: asset.price < 1 ? 4 : 2,
                                })}
                          </td>

                          {/* 24h Change */}
                          <td className="py-3 px-4 text-right font-mono font-medium">
                            <span className={asset.change24h >= 0 ? 'text-[#00d2ff]' : 'text-red-400'}>
                              {asset.change24h >= 0 ? '+' : ''}{asset.change24h.toFixed(2)}%
                            </span>
                          </td>

                          {/* Balance */}
                          <td className="py-3 px-4 text-right font-mono font-semibold text-white">
                            {hideBalances
                              ? '••••••'
                              : asset.balance === 0
                              ? '0.00'
                              : asset.balance.toLocaleString('en-US', {
                                  minimumFractionDigits: asset.symbol === 'BTC' ? 4 : 2,
                                  maximumFractionDigits: asset.symbol === 'BTC' ? 4 : 2,
                                })}
                          </td>

                          {/* Value USD */}
                          <td className="py-3 px-4 text-right font-mono font-bold text-white">
                            {hideBalances
                              ? '••••••'
                              : '$' + asset.usdVal.toLocaleString('en-US', {
                                  minimumFractionDigits: 2,
                                  maximumFractionDigits: 2,
                                })}
                          </td>

                          {/* Allocation */}
                          <td className="py-3 px-4 text-right">
                            <div className="flex flex-col items-end gap-1">
                              <span className="font-mono text-[11px] text-slate-300">
                                {hideBalances ? '—' : `${asset.allocationPct.toFixed(1)}%`}
                              </span>
                              <div className="w-16 h-1.5 bg-[#1a1f2b] rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-[#00d2ff] rounded-full transition-all"
                                  style={{ width: `${Math.min(100, Math.max(0, asset.allocationPct))}%` }}
                                />
                              </div>
                            </div>
                          </td>

                          {/* Quick Actions */}
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {/* Swap */}
                              <button
                                type="button"
                                onClick={() => {
                                  setSwapFromAsset(asset.symbol);
                                  setActiveModal('swap');
                                }}
                                className="px-2.5 py-1 rounded-lg bg-[#181d28] hover:bg-[#232a3a] border border-[#242b3b] text-slate-200 hover:text-white text-[11px] font-medium transition-all"
                              >
                                Swap
                              </button>

                              {/* Deposit */}
                              <button
                                type="button"
                                onClick={() => {
                                  setDepositAsset(asset.symbol);
                                  setActiveModal('deposit');
                                }}
                                className="px-2.5 py-1 rounded-lg bg-[#181d28] hover:bg-[#232a3a] border border-[#242b3b] text-slate-200 hover:text-white text-[11px] font-medium transition-all"
                              >
                                Deposit
                              </button>

                              {/* Trade */}
                              {asset.marketId && (
                                <button
                                  type="button"
                                  onClick={() => onTradeMarket?.(asset.marketId!)}
                                  className="px-2.5 py-1 rounded-lg bg-[#00d2ff]/10 hover:bg-[#00d2ff]/20 text-[#00d2ff] border border-[#00d2ff]/30 text-[11px] font-bold transition-all"
                                >
                                  Trade
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 2: PERPS (PERPETUAL FUTURES) ================= */}
      {activeTab === 'perps' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Perps Summary Header */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 p-5 rounded-2xl bg-[#090b10] border border-[#1b1f2b]">
            <div>
              <div className="text-xs text-slate-400">Cross Margin Balance</div>
              <div className="text-2xl font-bold font-mono text-white mt-1">
                ${availableBalance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400">Unrealized PnL</div>
              <div className={`text-2xl font-bold font-mono mt-1 ${unrealizedProfit >= 0 ? 'text-[#00d2ff]' : 'text-red-400'}`}>
                {unrealizedProfit >= 0 ? '+' : ''}${unrealizedProfit.toFixed(2)}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400">Active Positions</div>
              <div className="text-2xl font-bold font-mono text-white mt-1">
                {positions.length}
              </div>
            </div>
            <div>
              <div className="text-xs text-slate-400">Execution Engine</div>
              <div className="text-xs font-mono text-emerald-400 mt-2 flex items-center gap-1.5 font-bold">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Hyperliquid L1 Native</span>
              </div>
            </div>
          </div>

          {/* Open Positions Table */}
          <div className="bg-[#090b10] border border-[#1b1f2b] rounded-2xl overflow-hidden shadow-xl">
            <div className="p-4 border-b border-[#1b1f2b] flex items-center justify-between">
              <h3 className="text-sm font-bold text-white">Active Perpetual Positions</h3>
              <span className="text-xs text-slate-400 font-mono">{positions.length} Open</span>
            </div>

            {positions.length === 0 ? (
              <div className="py-14 text-center text-slate-500 text-xs space-y-2">
                <p>No active perpetual futures positions currently open.</p>
                <button
                  onClick={() => onTradeMarket?.('BTC-PERP')}
                  className="px-4 py-1.5 rounded-full bg-[#00d2ff] text-black font-bold text-xs"
                >
                  Open BTC-PERP Trade
                </button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-sans">
                  <thead>
                    <tr className="border-b border-[#1b1f2b] text-[11px] text-slate-500 font-mono">
                      <th className="py-2.5 px-4 font-normal">Market</th>
                      <th className="py-2.5 px-4 font-normal">Size</th>
                      <th className="py-2.5 px-4 font-normal">Entry Price</th>
                      <th className="py-2.5 px-4 font-normal">Mark Price</th>
                      <th className="py-2.5 px-4 font-normal">Liq. Price</th>
                      <th className="py-2.5 px-4 font-normal text-right">Unrealized PnL</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#14161e]">
                    {positions.map((pos) => (
                      <tr key={pos.id} className="hover:bg-[#11131a] transition-colors">
                        <td className="py-3 px-4 font-bold text-white font-mono flex items-center gap-2">
                          <span>{pos.symbol}</span>
                          <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${pos.side === 'long' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>
                            {pos.leverage}x {pos.side.toUpperCase()}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-200">
                          {pos.size.toFixed(4)} {pos.baseAsset}
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-400">
                          ${pos.entryPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-3 px-4 font-mono text-white">
                          ${pos.markPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-3 px-4 font-mono text-amber-400">
                          ${pos.liqPrice?.toLocaleString(undefined, { minimumFractionDigits: 2 }) || '—'}
                        </td>
                        <td className={`py-3 px-4 text-right font-mono font-bold ${pos.unrealizedPnl >= 0 ? 'text-[#00d2ff]' : 'text-red-400'}`}>
                          {pos.unrealizedPnl >= 0 ? '+' : ''}${pos.unrealizedPnl.toFixed(2)} ({pos.unrealizedPnlPercent >= 0 ? '+' : ''}{pos.unrealizedPnlPercent.toFixed(2)}%)
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ================= TAB 3: SPOT (SPOT HOLDINGS & CRYPTOCURRENCIES) ================= */}
      {activeTab === 'spot' && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Spot Header & Search Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-white">Spot Balances & Assets</h2>
              <p className="text-xs text-slate-400">
                Self-custodial assets held on Hyperliquid L1 & Arbitrum One
              </p>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={spotSearch}
                onChange={(e) => setSpotSearch(e.target.value)}
                placeholder="Search token..."
                className="w-full bg-[#0d1017] border border-[#1b1f2b] focus:border-[#00d2ff] rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none transition-all"
              />
            </div>
          </div>

          {/* Spot Assets Table */}
          <div className="bg-[#090b10] border border-[#1b1f2b] rounded-2xl overflow-hidden shadow-xl">
            <table className="w-full text-left text-xs font-sans">
              <thead>
                <tr className="border-b border-[#1b1f2b] text-[11px] text-slate-500 font-mono">
                  <th className="py-3 px-4 font-normal">Token</th>
                  <th className="py-3 px-4 font-normal text-right">Available Balance</th>
                  <th className="py-3 px-4 font-normal text-right">Price</th>
                  <th className="py-3 px-4 font-normal text-right">USD Value</th>
                  <th className="py-3 px-4 font-normal text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#14161e]">
                {spotAssetItems.map((asset) => (
                  <tr key={asset.symbol} className="hover:bg-[#11131a] transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <CryptoLogo symbol={asset.symbol} size="sm" />
                        <div>
                          <div className="font-bold text-white font-mono">{asset.symbol}</div>
                          <div className="text-[10px] text-slate-400">{asset.name}</div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4 text-right font-mono font-medium text-white">
                      {hideBalances
                        ? '••••••'
                        : asset.balance.toLocaleString(undefined, {
                            minimumFractionDigits: asset.symbol === 'BTC' ? 4 : 2,
                            maximumFractionDigits: asset.symbol === 'BTC' ? 4 : 2,
                          })}
                    </td>

                    <td className="py-3 px-4 text-right font-mono text-slate-300">
                      ${asset.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>

                    <td className="py-3 px-4 text-right font-mono font-bold text-white">
                      {hideBalances
                        ? '••••••'
                        : '$' + asset.usdVal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </td>

                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setDepositAsset(asset.symbol);
                            setActiveModal('deposit');
                          }}
                          className="px-2 py-1 rounded bg-[#161a24] hover:bg-[#202735] text-slate-300 hover:text-white text-[11px] font-semibold"
                        >
                          Deposit
                        </button>
                        <button
                          onClick={() => asset.marketId && onTradeMarket?.(asset.marketId)}
                          className="px-2 py-1 rounded bg-[#00d2ff]/10 hover:bg-[#00d2ff]/20 text-[#00d2ff] text-[11px] font-bold"
                        >
                          Trade
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ================= MODAL 1: SWAP ================= */}
      {activeModal === 'swap' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md bg-[#0a0c12] border border-[#1e293b] rounded-2xl shadow-2xl overflow-hidden p-6 font-sans">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1a1e2b]"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold text-white mb-1">Instant DEX Swap</h3>
            <p className="text-xs text-slate-400 mb-4">
              Swap tokens instantly with 0 slippage and 0 gas fees
            </p>

            {swapError && (
              <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{swapError}</span>
              </div>
            )}

            {swapSuccessMsg && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{swapSuccessMsg}</span>
              </div>
            )}

            <form onSubmit={handleSwapSubmit} className="space-y-3.5">
              {/* You Pay Section */}
              <div className="p-3.5 bg-[#12151e] border border-[#222838] rounded-xl space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-medium">You Pay</span>
                  <div className="flex items-center gap-1.5 font-mono text-[11px] text-slate-400">
                    <span>Balance:</span>
                    <span className="text-white font-bold">
                      {(tokenBalances[swapFromAsset] ?? (swapFromAsset === 'USDC' ? walletBalance : 0)).toLocaleString(undefined, { maximumFractionDigits: 4 })}
                    </span>
                    <button
                      type="button"
                      onClick={() => setSwapAmount(String(tokenBalances[swapFromAsset] ?? (swapFromAsset === 'USDC' ? walletBalance : 1000)))}
                      className="text-[#00d2ff] hover:underline ml-1 font-bold"
                    >
                      MAX
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-3">
                  <input
                    type="number"
                    value={swapAmount}
                    onChange={(e) => setSwapAmount(e.target.value)}
                    placeholder="0.0"
                    className="w-full bg-transparent text-xl font-mono font-bold text-white placeholder-slate-600 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setTokenPickerTarget('swapFrom')}
                    className="flex items-center gap-2 bg-[#1b202d] hover:bg-[#252b3d] border border-[#2c3345] hover:border-[#00d2ff] rounded-2xl px-3 py-2 text-xs font-bold text-white transition-all shadow-sm shrink-0"
                  >
                    <CryptoLogo symbol={swapFromAsset} size="xs" />
                    <span>{swapFromAsset}</span>
                    <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                  </button>
                </div>
              </div>

              {/* Flip Button */}
              <div className="flex justify-center -my-1 relative z-10">
                <button
                  type="button"
                  onClick={() => {
                    const temp = swapFromAsset;
                    setSwapFromAsset(swapToAsset);
                    setSwapToAsset(temp);
                  }}
                  className="w-8 h-8 rounded-full bg-[#1b202d] border border-[#2c3345] hover:border-[#00d2ff] text-slate-300 hover:text-white flex items-center justify-center transition-all shadow-md group"
                >
                  <ArrowRightLeft className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform" />
                </button>
              </div>

              {/* You Receive Section */}
              <div className="p-3.5 bg-[#12151e] border border-[#222838] rounded-xl space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-medium">You Receive (Estimated)</span>
                  <span className="text-[11px] text-slate-500 font-mono">0% Slippage</span>
                </div>

                <div className="flex items-center justify-between gap-3">
                  <div className="text-xl font-mono font-bold text-emerald-400">
                    {calculatedSwapOutput.toFixed(4)}
                  </div>
                  <button
                    type="button"
                    onClick={() => setTokenPickerTarget('swapTo')}
                    className="flex items-center gap-2 bg-[#1b202d] hover:bg-[#252b3d] border border-[#2c3345] hover:border-[#00d2ff] rounded-2xl px-3 py-2 text-xs font-bold text-white transition-all shadow-sm shrink-0"
                  >
                    <CryptoLogo symbol={swapToAsset} size="xs" />
                    <span>{swapToAsset}</span>
                    <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                  </button>
                </div>
              </div>

              {/* Rate & Fee Info */}
              <div className="p-2.5 bg-[#0d1017] border border-[#1b1f2b] rounded-xl space-y-1.5 text-[11px] font-mono text-slate-400">
                <div className="flex items-center justify-between">
                  <span>Exchange Rate</span>
                  <span className="text-white font-bold">
                    1 {swapFromAsset} ≈ {(getAssetPrice(swapFromAsset) / getAssetPrice(swapToAsset)).toFixed(6)} {swapToAsset}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Network Gas Fee</span>
                  <span className="text-emerald-400 font-bold">$0.00 (Zero Gas)</span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-white hover:bg-slate-100 text-black font-extrabold text-xs shadow-lg transition-all mt-2"
              >
                Confirm Swap ({swapFromAsset} → {swapToAsset})
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL 2: WITHDRAW ================= */}
      {activeModal === 'withdraw' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md bg-[#0a0c12] border border-[#1e293b] rounded-2xl shadow-2xl overflow-hidden p-6 font-sans">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1a1e2b]"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold text-white mb-1">Withdraw</h3>
            <p className="text-xs text-slate-400 mb-4">
              Transfer funds from Hyperliquid L1 to an external wallet or exchange
            </p>

            {withdrawError && (
              <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{withdrawError}</span>
              </div>
            )}

            {withdrawSuccessMsg && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{withdrawSuccessMsg}</span>
              </div>
            )}

            <form onSubmit={handleWithdrawSubmit} className="space-y-3.5">
              <div>
                <label className="text-xs font-semibold text-slate-300">Select Asset</label>
                <button
                  type="button"
                  onClick={() => setTokenPickerTarget('withdraw')}
                  className="w-full mt-1 flex items-center justify-between bg-[#121622] hover:bg-[#1a202d] border border-[#222838] hover:border-[#00d2ff] rounded-xl px-3 py-2 text-xs font-bold text-white transition-all"
                >
                  <div className="flex items-center gap-2">
                    <CryptoLogo symbol={withdrawAsset} size="xs" />
                    <span>{withdrawAsset}</span>
                    <span className="text-slate-400 font-normal text-[11px]">
                      ({PORTFOLIO_CRYPTO_LIST.find(c => c.symbol === withdrawAsset)?.name || withdrawAsset})
                    </span>
                  </div>
                  <ChevronDown className="w-4 h-4 text-slate-400" />
                </button>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300">Destination Address</label>
                <input
                  type="text"
                  value={withdrawAddress}
                  onChange={(e) => setWithdrawAddress(e.target.value)}
                  placeholder="0x..."
                  className="w-full mt-1 bg-[#121622] border border-[#222838] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#00d2ff] font-mono"
                />
              </div>

              <div>
                <div className="flex items-center justify-between text-xs">
                  <label className="font-semibold text-slate-300">Withdraw Amount</label>
                  <button
                    type="button"
                    onClick={() => setWithdrawAmount('1000')}
                    className="text-[#00d2ff] hover:underline font-mono"
                  >
                    Max
                  </button>
                </div>
                <input
                  type="number"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  placeholder="1000"
                  className="w-full mt-1 bg-[#121622] border border-[#222838] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#00d2ff] font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-white hover:bg-slate-100 text-black font-extrabold text-xs shadow-lg transition-all mt-2"
              >
                Confirm Withdrawal
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ================= MODAL 3: DEPOSIT ================= */}
      {activeModal === 'deposit' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md bg-[#0a0c12] border border-[#1e293b] rounded-2xl shadow-2xl overflow-hidden p-6 font-sans">
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1a1e2b]"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-lg font-bold text-white mb-1">Deposit</h3>
            <p className="text-xs text-slate-400 mb-4">
              Send tokens directly to your self-custody Hyperliquid L1 address
            </p>

            {depositSuccessMsg && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{depositSuccessMsg}</span>
              </div>
            )}

            <form onSubmit={handleDepositSubmit} className="space-y-3.5">
              <div>
                <label className="text-xs font-semibold text-slate-300">Select Asset</label>
                <button
                  type="button"
                  onClick={() => setTokenPickerTarget('deposit')}
                  className="w-full mt-1 flex items-center justify-between bg-[#121622] hover:bg-[#1a202d] border border-[#222838] hover:border-[#00d2ff] rounded-xl px-3 py-2 text-xs font-bold text-white transition-all"
                >
                  <div className="flex items-center gap-2">
                    <CryptoLogo symbol={depositAsset} size="xs" />
                    <span>{depositAsset}</span>
                    <span className="text-slate-400 font-normal text-[11px]">
                      ({PORTFOLIO_CRYPTO_LIST.find(c => c.symbol === depositAsset)?.name || depositAsset})
                    </span>
                  </div>
                  <ChevronDown className="w-4 h-4 text-slate-400" />
                </button>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300">Deposit Network</label>
                <select
                  value={depositNetwork}
                  onChange={(e) => setDepositNetwork(e.target.value)}
                  className="w-full mt-1 bg-[#121622] border border-[#222838] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#00d2ff]"
                >
                  <option value="Hyperliquid L1">Hyperliquid L1 (Native Zero-Gas)</option>
                  <option value="Arbitrum One">Arbitrum One</option>
                  <option value="Ethereum Mainnet">Ethereum Mainnet (ERC-20)</option>
                </select>
              </div>

              {/* Deposit Address Box */}
              <div className="p-3 bg-[#11141e] border border-[#222838] rounded-xl space-y-1">
                <span className="text-[10px] text-slate-500 uppercase font-mono">Your Deposit Address</span>
                <div className="flex items-center justify-between text-xs font-mono text-white">
                  <span>{walletAddress}</span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(walletAddress);
                      setCopiedDepositAddr(true);
                      setTimeout(() => setCopiedDepositAddr(false), 2000);
                    }}
                    className="p-1 text-slate-400 hover:text-[#00d2ff]"
                  >
                    {copiedDepositAddr ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <RefreshCw className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300">Amount to Credit</label>
                <input
                  type="number"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  className="w-full mt-1 bg-[#121622] border border-[#222838] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-[#00d2ff] font-mono"
                  placeholder="1000"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-white hover:bg-slate-100 text-black font-extrabold text-xs shadow-lg transition-all mt-2"
              >
                Confirm Deposit (+${depositAmount} {depositAsset})
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Global Token Selector Modal */}
      <TokenSelectorModal
        isOpen={tokenPickerTarget !== null}
        onClose={() => setTokenPickerTarget(null)}
        selectedToken={
          tokenPickerTarget === 'swapFrom'
            ? swapFromAsset
            : tokenPickerTarget === 'swapTo'
            ? swapToAsset
            : tokenPickerTarget === 'deposit'
            ? depositAsset
            : withdrawAsset
        }
        excludeToken={
          tokenPickerTarget === 'swapFrom'
            ? swapToAsset
            : tokenPickerTarget === 'swapTo'
            ? swapFromAsset
            : undefined
        }
        onSelectToken={(sym) => {
          if (tokenPickerTarget === 'swapFrom') setSwapFromAsset(sym);
          else if (tokenPickerTarget === 'swapTo') setSwapToAsset(sym);
          else if (tokenPickerTarget === 'deposit') setDepositAsset(sym);
          else if (tokenPickerTarget === 'withdraw') setWithdrawAsset(sym);
          setTokenPickerTarget(null);
        }}
      />
    </div>
  );
};
