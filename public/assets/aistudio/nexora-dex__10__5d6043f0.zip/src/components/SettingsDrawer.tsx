import React, { useState } from 'react';
import { useTrading } from '../context/TradingContext';
import { SUPPORTED_LANGUAGES, LanguageCode } from '../i18n/translations';
import {
  X,
  Shield,
  Key,
  Mail,
  Lock,
  Globe,
  Check,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  PlusCircle,
  RefreshCw,
  Sparkles,
  User,
  UserPlus,
  Zap,
  Copy,
  Trash2,
  Terminal,
  Code2,
  CheckCheck,
} from 'lucide-react';

interface SettingsDrawerProps {
  onClose: () => void;
  onOpenRegister?: () => void;
}

type SettingsTab = 'account' | 'language' | 'trading';

export const SettingsDrawer: React.FC<SettingsDrawerProps> = ({ onClose, onOpenRegister }) => {
  const {
    t,
    language,
    setLanguage,
    userEmail,
    updateEmail,
    updatePassword,
    faucetDeposit,
    walletAddress,
    currentUser,
  } = useTrading();

  const [activeTab, setActiveTab] = useState<SettingsTab>('account');

  // Change Email State
  const [newEmail, setNewEmail] = useState<string>('');
  const [emailStatus, setEmailStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Change Password State
  const [currentPassword, setCurrentPassword] = useState<string>('');
  const [newPassword, setNewPassword] = useState<string>('');
  const [confirmPassword, setConfirmPassword] = useState<string>('');
  const [showCurrentPass, setShowCurrentPass] = useState<boolean>(false);
  const [showNewPass, setShowNewPass] = useState<boolean>(false);
  const [passwordStatus, setPasswordStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Password strength calculator
  const getPasswordStrength = (pass: string) => {
    if (!pass) return { score: 0, label: '', color: 'bg-slate-700' };
    if (pass.length < 6) return { score: 1, label: 'Weak', color: 'bg-red-500' };
    const hasNum = /\d/.test(pass);
    const hasSpecial = /[^A-Za-z0-9]/.test(pass);
    if (pass.length >= 10 && hasNum && hasSpecial) {
      return { score: 3, label: 'Strong', color: 'bg-emerald-400' };
    }
    if (pass.length >= 7 && (hasNum || hasSpecial)) {
      return { score: 2, label: 'Good', color: 'bg-[#00d2ff]' };
    }
    return { score: 1, label: 'Weak', color: 'bg-amber-400' };
  };

  const passStrength = getPasswordStrength(newPassword);

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setEmailStatus(null);
    const res = updateEmail(newEmail);
    if (res.success) {
      setEmailStatus({ type: 'success', message: t('emailUpdated') });
      setNewEmail('');
    } else {
      setEmailStatus({ type: 'error', message: res.error || t('invalidEmail') });
    }
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordStatus(null);
    const res = updatePassword(currentPassword, newPassword, confirmPassword);
    if (res.success) {
      setPasswordStatus({ type: 'success', message: t('passwordUpdated') });
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } else {
      setPasswordStatus({ type: 'error', message: res.error || t('passwordMismatch') });
    }
  };

  // DEX API Key Management State
  const [apiKeys, setApiKeys] = useState<Array<{
    id: string;
    name: string;
    key: string;
    secret: string;
    createdAt: string;
    canTrade: boolean;
    canRead: boolean;
  }>>(() => {
    try {
      const saved = localStorage.getItem('nexora_dex_api_keys');
      return saved ? JSON.parse(saved) : [
        {
          id: 'key-1',
          name: 'AlgoTrading-Bot-01',
          key: 'nx_live_8f3a9e142b7c0d51f9a8e2b4c6d8e0f2',
          secret: 'sec_7d9a1c3e5f7b0a2d4e6f8a1b3c5d7e9f0a2b4c6d8e0f1a3b',
          createdAt: '2026-10-24',
          canRead: true,
          canTrade: true,
        }
      ];
    } catch {
      return [];
    }
  });

  const [isCreatingKey, setIsCreatingKey] = useState<boolean>(false);
  const [newKeyName, setNewKeyName] = useState<string>('');
  const [keyCanTrade, setKeyCanTrade] = useState<boolean>(true);
  const [keyCanRead, setKeyCanRead] = useState<boolean>(true);
  const [revealedSecrets, setRevealedSecrets] = useState<Record<string, boolean>>({});
  const [copiedKeyText, setCopiedKeyText] = useState<string | null>(null);

  const saveApiKeys = (keys: typeof apiKeys) => {
    setApiKeys(keys);
    try {
      localStorage.setItem('nexora_dex_api_keys', JSON.stringify(keys));
    } catch {}
  };

  const handleCreateApiKey = (e: React.FormEvent) => {
    e.preventDefault();
    const hex = (len: number) => {
      const chars = '0123456789abcdef';
      let res = '';
      for (let i = 0; i < len; i++) {
        res += chars[Math.floor(Math.random() * chars.length)];
      }
      return res;
    };

    const newKey = {
      id: 'key-' + Date.now(),
      name: newKeyName.trim() || `API-Key-${apiKeys.length + 1}`,
      key: 'nx_live_' + hex(32),
      secret: 'sec_' + hex(48),
      createdAt: new Date().toISOString().split('T')[0],
      canRead: keyCanRead,
      canTrade: keyCanTrade,
    };

    saveApiKeys([newKey, ...apiKeys]);
    setNewKeyName('');
    setIsCreatingKey(false);
  };

  const handleDeleteApiKey = (id: string) => {
    saveApiKeys(apiKeys.filter(k => k.id !== id));
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKeyText(label);
    setTimeout(() => setCopiedKeyText(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0a0c10] border border-[#1e293b] rounded-t-3xl sm:rounded-2xl p-5 shadow-2xl overflow-hidden font-sans max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#1e293b]/70 mb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#00d2ff]/15 border border-[#00d2ff]/30 flex items-center justify-center text-[#00d2ff]">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white leading-tight">
                {t('accountSettings')}
              </h3>
              <span className="text-[11px] text-slate-400 font-mono">
                Nexora DEX Security & Preferences
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1e293b] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 bg-[#10131d] p-1 rounded-xl border border-[#1e293b] mb-4">
          <button
            onClick={() => setActiveTab('account')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'account'
                ? 'bg-[#1e293b] text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            <span>{t('accountProfile')}</span>
          </button>

          <button
            onClick={() => setActiveTab('language')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'language'
                ? 'bg-[#1e293b] text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-[#00d2ff]" />
            <span>{t('preferences')}</span>
          </button>

          <button
            onClick={() => setActiveTab('trading')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'trading'
                ? 'bg-[#1e293b] text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Key className="w-3.5 h-3.5 text-amber-400" />
            <span>API Keys</span>
          </button>
        </div>

        {/* Scrollable Tab Body */}
        <div className="overflow-y-auto pr-1 flex-1 space-y-4">
          {activeTab === 'account' && (
            <div className="space-y-4">
              {/* Registered Account Status Card */}
              {currentUser && (
                <div className="p-4 bg-gradient-to-br from-[#121828] to-[#0a0d16] border border-[#1e293b] rounded-xl">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#00d2ff] to-[#0077ff] flex items-center justify-center text-black font-extrabold text-sm shadow-md shadow-[#00d2ff]/20">
                        {currentUser.username.slice(0, 1).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-white text-sm">
                            {currentUser.username}
                          </span>
                          <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-[#00d2ff]/15 text-[#00d2ff] border border-[#00d2ff]/30 font-bold">
                            {currentUser.vipTier}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          ID: <strong className="text-white">{currentUser.id}</strong> · {currentUser.email}
                        </div>
                      </div>
                    </div>

                    {onOpenRegister && (
                      <button
                        onClick={onOpenRegister}
                        className="px-3 py-1.5 rounded-lg bg-[#00d2ff]/15 hover:bg-[#00d2ff]/25 border border-[#00d2ff]/40 text-[#00d2ff] text-xs font-bold transition-all flex items-center gap-1.5 shrink-0"
                      >
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Register New</span>
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-3 gap-2 pt-2 border-t border-[#1e293b]/60 text-[10px] font-mono text-slate-400">
                    <div>
                      <span>Maker Fee:</span>
                      <div className="text-emerald-400 font-bold text-xs">0.00% (Free)</div>
                    </div>
                    <div>
                      <span>Taker Fee:</span>
                      <div className="text-white font-bold text-xs">{currentUser.takerFeeRate}%</div>
                    </div>
                    <div>
                      <span>Registered:</span>
                      <div className="text-slate-300 font-bold text-xs">{currentUser.registeredAt}</div>
                    </div>
                  </div>
                </div>
              )}

              {/* Change Email Section */}
              <div className="p-4 bg-[#10131d] border border-[#1e293b] rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-[#00d2ff]" />
                    <span className="font-bold text-white text-xs">{t('changeEmail')}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {t('currentEmail')}: <strong className="text-white">{userEmail}</strong>
                  </span>
                </div>

                <form onSubmit={handleEmailSubmit} className="space-y-2.5">
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">
                      {t('newEmail')}
                    </label>
                    <input
                      type="email"
                      value={newEmail}
                      onChange={(e) => setNewEmail(e.target.value)}
                      placeholder="e.g. yourname@domain.com"
                      className="w-full bg-[#161a26] border border-[#1e293b] rounded-lg py-2 px-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#00d2ff] font-mono"
                    />
                  </div>

                  {emailStatus && (
                    <div
                      className={`p-2 rounded-lg text-xs flex items-center gap-1.5 ${
                        emailStatus.type === 'success'
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : 'bg-red-500/15 text-red-400 border border-red-500/30'
                      }`}
                    >
                      {emailStatus.type === 'success' ? (
                        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      )}
                      <span>{emailStatus.message}</span>
                    </div>
                  )}

                  <div className="flex justify-end pt-1">
                    <button
                      type="submit"
                      disabled={!newEmail}
                      className="py-1.5 px-4 rounded-lg bg-[#00d2ff] hover:bg-[#00bfe8] disabled:opacity-40 disabled:pointer-events-none text-black font-bold text-xs transition-colors"
                    >
                      {t('saveEmail')}
                    </button>
                  </div>
                </form>
              </div>

              {/* Change Password Section */}
              <div className="p-4 bg-[#10131d] border border-[#1e293b] rounded-xl space-y-3">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-[#00d2ff]" />
                  <span className="font-bold text-white text-xs">{t('updatePassword')}</span>
                </div>

                <form onSubmit={handlePasswordSubmit} className="space-y-3">
                  {/* Current Password */}
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">
                      {t('currentPassword')}
                    </label>
                    <div className="relative">
                      <input
                        type={showCurrentPass ? 'text' : 'password'}
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full bg-[#161a26] border border-[#1e293b] rounded-lg py-2 pl-3 pr-9 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#00d2ff] font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCurrentPass(!showCurrentPass)}
                        className="absolute right-2.5 top-2.5 text-slate-400 hover:text-white"
                      >
                        {showCurrentPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  {/* New Password */}
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-[11px] text-slate-400">
                        {t('newPassword')}
                      </label>
                      {newPassword && (
                        <span className="text-[10px] font-mono text-slate-400">
                          Strength: <strong className="text-white">{passStrength.label}</strong>
                        </span>
                      )}
                    </div>
                    <div className="relative">
                      <input
                        type={showNewPass ? 'text' : 'password'}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="Min 6 characters"
                        className="w-full bg-[#161a26] border border-[#1e293b] rounded-lg py-2 pl-3 pr-9 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#00d2ff] font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewPass(!showNewPass)}
                        className="absolute right-2.5 top-2.5 text-slate-400 hover:text-white"
                      >
                        {showNewPass ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    {/* Strength Bar */}
                    {newPassword && (
                      <div className="w-full h-1 bg-[#1e293b] rounded-full mt-1.5 overflow-hidden">
                        <div
                          className={`h-full ${passStrength.color} transition-all duration-300`}
                          style={{ width: `${(passStrength.score / 3) * 100}%` }}
                        />
                      </div>
                    )}
                  </div>

                  {/* Confirm Password */}
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">
                      {t('confirmNewPassword')}
                    </label>
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Repeat new password"
                      className="w-full bg-[#161a26] border border-[#1e293b] rounded-lg py-2 px-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#00d2ff] font-mono"
                    />
                  </div>

                  {passwordStatus && (
                    <div
                      className={`p-2 rounded-lg text-xs flex items-center gap-1.5 ${
                        passwordStatus.type === 'success'
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : 'bg-red-500/15 text-red-400 border border-red-500/30'
                      }`}
                    >
                      {passwordStatus.type === 'success' ? (
                        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      )}
                      <span>{passwordStatus.message}</span>
                    </div>
                  )}

                  <div className="flex justify-end pt-1">
                    <button
                      type="submit"
                      disabled={!newPassword || !confirmPassword}
                      className="py-1.5 px-4 rounded-lg bg-[#00d2ff] hover:bg-[#00bfe8] disabled:opacity-40 disabled:pointer-events-none text-black font-bold text-xs transition-colors"
                    >
                      {t('updatePassword')}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {activeTab === 'language' && (
            <div className="space-y-4">
              <div className="p-3 bg-[#10131d] border border-[#1e293b] rounded-xl">
                <span className="text-xs font-bold text-white block mb-1">
                  {t('selectLanguage')}
                </span>
                <p className="text-[11px] text-slate-400 mb-3">
                  Choose your preferred language for tickers, orders, charts, and trading navigation.
                </p>
                {/* 12 Global Languages Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 max-h-[400px] overflow-y-auto pr-1">
                  {SUPPORTED_LANGUAGES.map((lang) => {
                    const isSelected = language === lang.code;
                    return (
                      <div
                        key={lang.code}
                        onClick={() => setLanguage(lang.code)}
                        className={`p-3 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-[#00d2ff]/10 border-[#00d2ff] shadow-md shadow-[#00d2ff]/10'
                            : 'bg-[#141824] border-[#1e293b] hover:border-slate-600'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-2xl select-none">{lang.flag}</span>
                          <div>
                            <span className="text-xs font-bold text-white block">
                              {lang.nativeName}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">
                              {lang.name}
                            </span>
                          </div>
                        </div>

                        {isSelected && (
                          <div className="w-5 h-5 rounded-full bg-[#00d2ff] text-black flex items-center justify-center">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'trading' && (
            <div className="space-y-4">
              {/* DEX Trading API Keys Management Card */}
              <div className="p-4 bg-[#10131d] border border-[#1e293b] rounded-xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
                      <Key className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="font-bold text-white text-xs block leading-tight">
                        DEX Trading API Keys
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        Programmatic & Algorithmic Bot Integration
                      </span>
                    </div>
                  </div>

                  {!isCreatingKey && (
                    <button
                      onClick={() => setIsCreatingKey(true)}
                      className="px-2.5 py-1.5 rounded-lg bg-[#00d2ff] hover:bg-[#38bdf8] text-black font-bold text-xs transition-all flex items-center gap-1.5 shadow-sm shadow-[#00d2ff]/20 cursor-pointer"
                    >
                      <PlusCircle className="w-3.5 h-3.5" />
                      <span>Create Key</span>
                    </button>
                  )}
                </div>

                <p className="text-[11px] text-slate-400">
                  Connect automated trading bots (Hummingbot, Python, Webhooks) directly to Nexora DEX with sub-second execution.
                </p>

                {/* Create Key Form */}
                {isCreatingKey && (
                  <form
                    onSubmit={handleCreateApiKey}
                    className="p-3.5 bg-[#151926] border border-[#00d2ff]/40 rounded-xl space-y-3 animate-in fade-in zoom-in-95 duration-150"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white flex items-center gap-1.5">
                        <Terminal className="w-3.5 h-3.5 text-[#00d2ff]" />
                        Generate New API Key Pair
                      </span>
                      <button
                        type="button"
                        onClick={() => setIsCreatingKey(false)}
                        className="text-slate-400 hover:text-white p-1"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-400 block mb-1">
                        Key Label / Bot Identifier
                      </label>
                      <input
                        type="text"
                        value={newKeyName}
                        onChange={(e) => setNewKeyName(e.target.value)}
                        placeholder="e.g. TrendFollower-Bot-01"
                        required
                        className="w-full bg-[#0c0e15] border border-[#21283b] rounded-lg py-1.5 px-3 text-white text-xs font-mono focus:outline-none focus:border-[#00d2ff]"
                      />
                    </div>

                    <div className="space-y-1.5 text-xs font-mono">
                      <span className="text-[11px] text-slate-400 block font-sans">Permissions</span>
                      <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                        <input
                          type="checkbox"
                          checked={keyCanRead}
                          onChange={(e) => setKeyCanRead(e.target.checked)}
                          className="rounded border-[#2a3449] text-[#00d2ff] focus:ring-0"
                        />
                        <span>Read Market Data & Positions</span>
                      </label>

                      <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                        <input
                          type="checkbox"
                          checked={keyCanTrade}
                          onChange={(e) => setKeyCanTrade(e.target.checked)}
                          className="rounded border-[#2a3449] text-[#00d2ff] focus:ring-0"
                        />
                        <span>Trade Execution (Perps & Spot)</span>
                      </label>

                      <label className="flex items-center gap-2 text-slate-500 cursor-not-allowed">
                        <input
                          type="checkbox"
                          disabled
                          checked={false}
                          className="rounded border-[#2a3449] text-slate-600 focus:ring-0"
                        />
                        <span>Withdrawals (Blocked for Safety)</span>
                      </label>
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#1e293b]">
                      <button
                        type="button"
                        onClick={() => setIsCreatingKey(false)}
                        className="px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:text-white transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-3.5 py-1.5 rounded-lg bg-[#00d2ff] hover:bg-[#38bdf8] text-black font-bold text-xs transition-all shadow-sm"
                      >
                        Generate API Key
                      </button>
                    </div>
                  </form>
                )}

                {/* API Keys List */}
                <div className="space-y-2.5">
                  {apiKeys.length === 0 ? (
                    <div className="text-center py-4 bg-[#0a0c10] border border-[#1e293b]/60 rounded-xl text-xs text-slate-500">
                      No API keys generated yet. Click "Create Key" above.
                    </div>
                  ) : (
                    apiKeys.map((k) => {
                      const isRevealed = !!revealedSecrets[k.id];
                      return (
                        <div
                          key={k.id}
                          className="p-3 bg-[#0c0e15] border border-[#1e293b] rounded-xl space-y-2 font-mono text-xs"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-bold text-white text-xs font-sans">
                                {k.name}
                              </span>
                              <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 font-bold">
                                ACTIVE
                              </span>
                              {k.canTrade && (
                                <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#00d2ff]/15 text-[#00d2ff] border border-[#00d2ff]/30">
                                  TRADE
                                </span>
                              )}
                              {k.canRead && (
                                <span className="text-[9px] px-1.5 py-0.2 rounded bg-purple-500/15 text-purple-300 border border-purple-500/30">
                                  READ
                                </span>
                              )}
                            </div>

                            <button
                              onClick={() => handleDeleteApiKey(k.id)}
                              className="text-slate-500 hover:text-red-400 transition-colors p-1"
                              title="Revoke / Delete Key"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {/* API Key Row */}
                          <div className="space-y-1">
                            <div className="flex items-center justify-between text-[10px] text-slate-500 font-sans">
                              <span>API Key:</span>
                              <span className="font-mono text-[9px] text-slate-600">Created: {k.createdAt}</span>
                            </div>
                            <div className="flex items-center gap-1.5 bg-[#141824] px-2.5 py-1.5 rounded-lg border border-[#1e293b]">
                              <span className="text-[11px] text-slate-300 truncate flex-1 select-all font-mono">
                                {k.key}
                              </span>
                              <button
                                onClick={() => copyToClipboard(k.key, `key-${k.id}`)}
                                className="text-slate-400 hover:text-white transition-colors shrink-0 p-1 rounded hover:bg-[#1f2638]"
                                title="Copy API Key"
                              >
                                {copiedKeyText === `key-${k.id}` ? (
                                  <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                              </button>
                            </div>
                          </div>

                          {/* API Secret Row */}
                          <div className="space-y-1">
                            <span className="text-[10px] text-slate-500 font-sans block">
                              API Secret:
                            </span>
                            <div className="flex items-center gap-1.5 bg-[#141824] px-2.5 py-1.5 rounded-lg border border-[#1e293b]">
                              <span className="text-[11px] text-slate-300 truncate flex-1 select-all font-mono">
                                {isRevealed ? k.secret : '••••••••••••••••••••••••••••••••'}
                              </span>
                              <button
                                onClick={() => setRevealedSecrets(prev => ({ ...prev, [k.id]: !prev[k.id] }))}
                                className="text-slate-400 hover:text-white transition-colors shrink-0 p-1 rounded hover:bg-[#1f2638]"
                                title={isRevealed ? "Hide Secret" : "Show Secret"}
                              >
                                {isRevealed ? (
                                  <EyeOff className="w-3.5 h-3.5" />
                                ) : (
                                  <Eye className="w-3.5 h-3.5" />
                                )}
                              </button>
                              <button
                                onClick={() => copyToClipboard(k.secret, `sec-${k.id}`)}
                                className="text-slate-400 hover:text-white transition-colors shrink-0 p-1 rounded hover:bg-[#1f2638]"
                                title="Copy Secret"
                              >
                                {copiedKeyText === `sec-${k.id}` ? (
                                  <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
                                ) : (
                                  <Copy className="w-3.5 h-3.5" />
                                )}
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>

                {/* API Quick Integration Specs */}
                <div className="p-2.5 bg-[#080a10] border border-[#1e293b]/70 rounded-xl space-y-1 text-[11px] font-mono text-slate-400">
                  <div className="flex items-center gap-1.5 text-slate-300 font-sans font-bold text-xs mb-1">
                    <Code2 className="w-3.5 h-3.5 text-[#00d2ff]" />
                    <span>Developer Endpoint Reference</span>
                  </div>
                  <div>Base URL: <span className="text-white">https://api.nexora.dex/v1</span></div>
                  <div>Header: <span className="text-amber-400">X-NEXORA-APIKEY</span>: &lt;API_KEY&gt;</div>
                  <div>WebSocket: <span className="text-emerald-400">wss://stream.nexora.dex/ws</span></div>
                </div>
              </div>

              {/* Live Trading Engine & Settlement */}
              <div className="p-4 bg-[#10131d] border border-[#1e293b] rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Zap className="w-4 h-4 text-blue-400" />
                    <span className="font-bold text-white text-xs">Live Trading Engine</span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-blue-500/15 border border-blue-500/30 text-blue-400 font-bold">
                    Hyperliquid L1
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Zero gas fees, 12ms sub-second oracle latency, and institutional self-custodial trading execution.
                </p>

                <div className="grid grid-cols-2 gap-2 text-[11px] font-mono pt-1 text-slate-400">
                  <div className="p-2 rounded-lg bg-[#141622] border border-[#1e293b]">
                    <span className="text-slate-500 block text-[10px]">Settlement</span>
                    <span className="text-white font-bold">Sub-Second Finality</span>
                  </div>
                  <div className="p-2 rounded-lg bg-[#141622] border border-[#1e293b]">
                    <span className="text-slate-500 block text-[10px]">Gas Cost</span>
                    <span className="text-emerald-400 font-bold">$0.00 (Zero Gas)</span>
                  </div>
                </div>
              </div>

              {/* Active Smart Account Details */}
              <div className="p-3.5 bg-[#10131d] border border-[#1e293b] rounded-xl space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-slate-300">
                    <Key className="w-4 h-4 text-[#00d2ff]" />
                    <span className="font-bold text-white">{t('smartAccount')}</span>
                  </div>
                  <span className="text-[10px] text-emerald-400 font-mono font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    Connected
                  </span>
                </div>
                <div className="p-2 bg-[#161a26] border border-[#1e293b] rounded-lg font-mono text-xs text-slate-300 select-all">
                  {walletAddress}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Done Button */}
        <div className="pt-3 mt-3 border-t border-[#1e293b]/70 flex justify-end">
          <button
            onClick={onClose}
            className="py-2 px-6 rounded-xl bg-[#00d2ff] hover:bg-[#00bfe8] text-black font-bold text-xs transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
