import React, { useState } from 'react';
import { useTrading } from '../context/TradingContext';
import { FaqSection } from './FaqSection';
import { AuthModal } from './AuthModal';
import { AppView } from '../App';
import {
  Lock,
  Shield,
  Zap,
  Globe,
  ArrowRight,
  User,
  Mail,
  CheckCircle2,
  AlertCircle,
  Users,
  ChevronDown,
  X,
  Wallet,
  Sparkles,
  ExternalLink,
} from 'lucide-react';

interface StandaloneAuthGateProps {
  initialMode?: 'register' | 'login';
  intendedDestination?: AppView;
  authGuardNotice?: string | null;
  onClearNotice?: () => void;
  onOpenAuthModal?: (mode: 'register' | 'login') => void;
  showAuthModal?: boolean;
  onCloseAuthModal?: () => void;
  onAuthenticated?: (destination?: AppView) => void;
}

export const StandaloneAuthGate: React.FC<StandaloneAuthGateProps> = ({
  initialMode = 'register',
  intendedDestination = 'trade',
  authGuardNotice = null,
  onClearNotice,
  onOpenAuthModal,
  showAuthModal = false,
  onCloseAuthModal,
  onAuthenticated,
}) => {
  const { registerUser, loginUser } = useTrading();

  const [activeTab, setActiveTab] = useState<'register' | 'login'>(initialMode);
  const [internalAuthModal, setInternalAuthModal] = useState<boolean>(false);
  const [internalModalMode, setInternalModalMode] = useState<'register' | 'login'>(initialMode);

  // Form inputs for Registration
  const [fullName, setFullName] = useState<string>('Anatoli Marchenko');
  const [username, setUsername] = useState<string>('AnatoliM');
  const [regEmail, setRegEmail] = useState<string>('anatolimarcenko980@gmail.com');
  const [regPassword, setRegPassword] = useState<string>('HyperDex2026!');
  const [confirmPassword, setConfirmPassword] = useState<string>('HyperDex2026!');
  const [referralCode, setReferralCode] = useState<string>('NEXORA-VIP');

  // Form inputs for Login
  const [loginEmail, setLoginEmail] = useState<string>('anatolimarcenko980@gmail.com');
  const [loginPassword, setLoginPassword] = useState<string>('HyperDex2026!');

  // Form state
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    if (!fullName.trim()) {
      setFeedback({ type: 'error', message: 'Please enter your full name.' });
      return;
    }
    if (!username.trim() || username.length < 3) {
      setFeedback({ type: 'error', message: 'Username must be at least 3 characters long.' });
      return;
    }
    if (!regEmail.trim() || !regEmail.includes('@')) {
      setFeedback({ type: 'error', message: 'Please enter a valid email address.' });
      return;
    }
    if (regPassword.length < 6) {
      setFeedback({ type: 'error', message: 'Password must be at least 6 characters.' });
      return;
    }
    if (regPassword !== confirmPassword) {
      setFeedback({ type: 'error', message: 'Passwords do not match.' });
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const res = registerUser({
        fullName: fullName.trim(),
        username: username.trim(),
        email: regEmail.trim(),
        password: regPassword,
        referralCode: referralCode.trim() || undefined,
        authMethod: 'email',
      });
      setIsSubmitting(false);

      if (res.success) {
        setFeedback({
          type: 'success',
          message: `Account created successfully! Unlocking trading terminal...`,
        });
        setTimeout(() => {
          if (onAuthenticated) {
            onAuthenticated(intendedDestination);
          }
        }, 600);
      } else {
        setFeedback({ type: 'error', message: res.error || 'Registration failed.' });
      }
    }, 400);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    if (!loginEmail.trim()) {
      setFeedback({ type: 'error', message: 'Please enter your email or username.' });
      return;
    }
    if (!loginPassword) {
      setFeedback({ type: 'error', message: 'Please enter your password.' });
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      const res = loginUser({
        emailOrUsername: loginEmail.trim(),
        password: loginPassword,
      });
      setIsSubmitting(false);

      if (res.success) {
        setFeedback({
          type: 'success',
          message: `Authentication verified! Redirecting to ${intendedDestination === 'trade' ? 'Trading Terminal' : intendedDestination}...`,
        });
        setTimeout(() => {
          if (onAuthenticated) {
            onAuthenticated(intendedDestination);
          }
        }, 600);
      } else {
        setFeedback({ type: 'error', message: res.error || 'Invalid credentials.' });
      }
    }, 400);
  };

  // Instant 1-Click test login for fast evaluation
  const handleQuickDemoAccess = (role: 'user' | 'trader') => {
    setIsSubmitting(true);
    setTimeout(() => {
      const userParams =
        role === 'user'
          ? {
              fullName: 'Anatoli Marchenko',
              username: 'AnatoliM',
              email: 'anatolimarcenko980@gmail.com',
              authMethod: 'google' as const,
            }
          : {
              fullName: 'Hyperliquid Trader',
              username: 'HypePro',
              email: 'trader@nexora.dex',
              authMethod: 'email' as const,
            };

      const res = registerUser(userParams);
      setIsSubmitting(false);

      if (res.success) {
        setFeedback({
          type: 'success',
          message: 'Authenticated! Unlocking platform...',
        });
        setTimeout(() => {
          if (onAuthenticated) {
            onAuthenticated(intendedDestination);
          }
        }, 500);
      }
    }, 300);
  };

  const scrollToFaq = () => {
    const el = document.getElementById('faq-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const isModalOpen = showAuthModal || internalAuthModal;
  const currentModalMode = onOpenAuthModal ? initialMode : internalModalMode;
  const handleCloseModal = () => {
    if (onCloseAuthModal) onCloseAuthModal();
    setInternalAuthModal(false);
  };

  return (
    <div className="min-h-screen bg-[#050608] text-white flex flex-col font-sans selection:bg-[#00d2ff]/20 selection:text-[#00d2ff]">
      {/* 
        STANDALONE TOP BAR:
        Strictly contains ONLY branding, access status, and Auth actions.
        NO restricted trading navigation links (Markets, Terminal, Calendar, Copytrading, Portfolio are hidden).
      */}
      <header className="sticky top-0 z-40 w-full border-b border-[#181d28] bg-[#07090e]/95 backdrop-blur-md px-4 sm:px-6 py-3.5 flex items-center justify-between">
        {/* Brand Logo */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-br from-[#00d2ff] via-[#0088cc] to-[#0a192f] p-0.5 shadow-[0_0_15px_rgba(0,210,255,0.4)]">
            <div className="w-full h-full bg-[#07090e] rounded-[10px] flex items-center justify-center">
              <Zap className="w-5 h-5 text-[#00d2ff]" />
            </div>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-base tracking-tight text-white font-sans">
                NEXORA
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#00d2ff]/10 text-[#00d2ff] border border-[#00d2ff]/30 font-mono">
                DEX
              </span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">
              Hyperliquid L1 Engine
            </span>
          </div>
        </div>

        {/* Right Auth Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => {
              setActiveTab('login');
              setFeedback(null);
              window.scrollTo({ top: 120, behavior: 'smooth' });
            }}
            className="px-3.5 py-1.5 rounded-full text-xs font-semibold text-slate-300 hover:text-white bg-[#0e131d] border border-[#222b3d] hover:border-slate-500 transition-all cursor-pointer"
          >
            Sign In
          </button>
          <button
            onClick={() => {
              setActiveTab('register');
              setFeedback(null);
              window.scrollTo({ top: 120, behavior: 'smooth' });
            }}
            className="px-4 py-1.5 rounded-full text-xs font-bold text-black bg-[#00d2ff] hover:bg-[#38bdf8] shadow-[0_0_12px_rgba(0,210,255,0.3)] transition-all cursor-pointer"
          >
            Create Account
          </button>
        </div>
      </header>

      {/* Main Standalone Page Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 pb-20 flex flex-col items-center">
        {/* Protected Route Notice Banner (If user attempted to access a guarded link) */}
        {authGuardNotice && (
          <div className="w-full max-w-4xl mb-6 p-4 rounded-2xl bg-gradient-to-r from-amber-500/15 via-[#1a140d] to-amber-500/10 border border-amber-500/40 text-amber-200 flex items-center justify-between gap-3 shadow-xl animate-in fade-in slide-in-from-top-2 duration-200">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <div className="text-[11px] font-bold text-amber-300 uppercase tracking-wider font-mono">
                  Authentication Required
                </div>
                <div className="text-xs text-amber-100/90 leading-snug">
                  {authGuardNotice}
                </div>
              </div>
            </div>
            {onClearNotice && (
              <button
                onClick={onClearNotice}
                className="p-1 rounded-lg text-amber-400/80 hover:text-white hover:bg-amber-500/20 transition-colors"
                title="Dismiss"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        )}

        {/* 
          COMPONENT 1: REGISTER / LOGIN OPTIONS
          (Email/Password Registration & Login + Instant Access)
        */}
        <section className="w-full max-w-5xl py-4 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Form & Access */}
          <div className="lg:col-span-7 bg-[#0b0e14] border border-[#1b2130] rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-[#00d2ff] to-transparent opacity-80" />

            {/* Mode Switch Tabs */}
            <div className="flex items-center justify-between border-b border-[#181d2a] pb-4 mb-6">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => { setActiveTab('register'); setFeedback(null); }}
                  className={`text-lg sm:text-xl font-extrabold tracking-tight pb-1 transition-colors ${
                    activeTab === 'register'
                      ? 'text-white border-b-2 border-[#00d2ff]'
                      : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  Create Account
                </button>
                <button
                  type="button"
                  onClick={() => { setActiveTab('login'); setFeedback(null); }}
                  className={`text-lg sm:text-xl font-extrabold tracking-tight pb-1 transition-colors ${
                    activeTab === 'login'
                      ? 'text-white border-b-2 border-[#00d2ff]'
                      : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  Sign In
                </button>
              </div>

              <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
                <Shield className="w-3.5 h-3.5 text-[#00d2ff]" />
                <span>Self-Custodial</span>
              </div>
            </div>

            {/* Feedback alert */}
            {feedback && (
              <div
                className={`mb-5 p-3.5 rounded-xl text-xs font-mono flex items-center gap-2.5 ${
                  feedback.type === 'success'
                    ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
                    : 'bg-red-500/10 border border-red-500/30 text-red-300'
                }`}
              >
                {feedback.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                )}
                <span>{feedback.message}</span>
              </div>
            )}

            {/* Form Section */}
            {activeTab === 'register' ? (
              <form onSubmit={handleRegisterSubmit} className="flex flex-col gap-3.5 text-xs font-mono">
                <div>
                  <label className="text-slate-400 block mb-1">Full Name</label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="e.g. Satoshi Nakamoto"
                      className="w-full bg-[#121622] border border-[#21283b] rounded-xl py-2 pl-9 pr-3 text-white text-xs focus:outline-none focus:border-[#00d2ff]"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-400 block mb-1">Username</label>
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="trader_tag"
                      className="w-full bg-[#121622] border border-[#21283b] rounded-xl py-2 px-3 text-white text-xs focus:outline-none focus:border-[#00d2ff]"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Referral Code (Optional)</label>
                    <input
                      type="text"
                      value={referralCode}
                      onChange={(e) => setReferralCode(e.target.value)}
                      placeholder="NEXORA-VIP"
                      className="w-full bg-[#121622] border border-[#21283b] rounded-xl py-2 px-3 text-white text-xs focus:outline-none focus:border-[#00d2ff]"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Email Address</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="you@domain.com"
                      className="w-full bg-[#121622] border border-[#21283b] rounded-xl py-2 pl-9 pr-3 text-white text-xs focus:outline-none focus:border-[#00d2ff]"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-slate-400 block mb-1">Password</label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                      <input
                        type="password"
                        value={regPassword}
                        onChange={(e) => setRegPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full bg-[#121622] border border-[#21283b] rounded-xl py-2 pl-9 pr-3 text-white text-xs focus:outline-none focus:border-[#00d2ff]"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-slate-400 block mb-1">Confirm Password</label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                      <input
                        type="password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full bg-[#121622] border border-[#21283b] rounded-xl py-2 pl-9 pr-3 text-white text-xs focus:outline-none focus:border-[#00d2ff]"
                        required
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="mt-3 w-full py-3 rounded-full bg-[#00d2ff] hover:bg-[#38bdf8] text-black font-extrabold text-xs sm:text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <span>{isSubmitting ? 'Registering Account...' : 'Complete Sign Up & Access Terminal'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            ) : (
              <form onSubmit={handleLoginSubmit} className="flex flex-col gap-4 text-xs font-mono">
                <div>
                  <label className="text-slate-400 block mb-1">Email or Username</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      placeholder="you@domain.com or username"
                      className="w-full bg-[#121622] border border-[#21283b] rounded-xl py-2.5 pl-9 pr-3 text-white text-xs focus:outline-none focus:border-[#00d2ff]"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Password</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                    <input
                      type="password"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full bg-[#121622] border border-[#21283b] rounded-xl py-2.5 pl-9 pr-3 text-white text-xs focus:outline-none focus:border-[#00d2ff]"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="mt-2 w-full py-3 rounded-full bg-white hover:bg-neutral-200 text-black font-extrabold text-xs sm:text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <span>{isSubmitting ? 'Verifying...' : 'Sign In & Enter Terminal'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            )}

            {/* Quick 1-Click Instant Demo Login (For frictionless evaluation) */}
            <div className="mt-6 pt-5 border-t border-[#171c28]">
              <span className="text-[11px] text-slate-400 font-mono text-center block mb-2.5">
                Instant 1-Click Testing Access:
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <button
                  type="button"
                  onClick={() => handleQuickDemoAccess('user')}
                  disabled={isSubmitting}
                  className="py-2.5 px-3 rounded-xl bg-[#141a27] hover:bg-[#1d2538] border border-[#222a3d] text-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Zap className="w-3.5 h-3.5 text-[#00d2ff]" />
                  <span>Instant 1-Click Access</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickDemoAccess('trader')}
                  disabled={isSubmitting}
                  className="py-2.5 px-3 rounded-xl bg-[#141a27] hover:bg-[#1d2538] border border-[#222a3d] text-white flex items-center justify-center gap-1.5 transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Globe className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Demo Trader</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Platform Overview & Value Proposition */}
          <div className="lg:col-span-5 flex flex-col gap-4 text-left">
            <div className="bg-[#0b0e14] border border-[#1b2130] rounded-3xl p-6 sm:p-7 shadow-xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#00d2ff]/10 border border-[#00d2ff]/30 text-[#00d2ff] text-xs font-mono mb-4">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Hyperliquid L1 Engine</span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight leading-tight">
                Any market.<br />
                Anywhere.<br />
                On-chain.
              </h2>
              <p className="text-xs sm:text-sm text-slate-400 mt-2.5 leading-relaxed">
                Crypto, tokenized US equities, commodities, and FX perps — unified in one ultra-fast institutional order book.
              </p>

              {/* Core Pillars */}
              <div className="flex flex-col gap-3.5 mt-6 text-xs text-slate-300">
                <div className="flex items-start gap-3 p-3 rounded-2xl bg-[#0f131d] border border-[#1d2436]">
                  <div className="w-7 h-7 rounded-lg bg-[#00d2ff]/10 text-[#00d2ff] flex items-center justify-center shrink-0 mt-0.5">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-white block">100% Self-Custodial</span>
                    <span className="text-[11px] text-slate-400">
                      Your keys, your crypto. Funds remain strictly inside smart contract vaults with zero counterparty risk.
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-2xl bg-[#0f131d] border border-[#1d2436]">
                  <div className="w-7 h-7 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                    <Zap className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-white block">Sub-Second Execution & 0 Gas</span>
                    <span className="text-[11px] text-slate-400">
                      12ms latency, native Hyperliquid L1 order matching engine, zero gas fees to place or cancel orders.
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-2xl bg-[#0f131d] border border-[#1d2436]">
                  <div className="w-7 h-7 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center shrink-0 mt-0.5">
                    <Users className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-white block">1-Click Copy Trading</span>
                    <span className="text-[11px] text-slate-400">
                      Mirror verified top-tier onchain traders automatically with proportional allocation and risk caps.
                    </span>
                  </div>
                </div>
              </div>

              {/* Downward jump link to FAQ */}
              <div className="mt-6 pt-4 border-t border-[#171c28]">
                <button
                  type="button"
                  onClick={scrollToFaq}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#121622] hover:bg-[#1a2130] text-slate-300 hover:text-white text-xs font-mono flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <span>Explore FAQ & Architecture</span>
                  <ChevronDown className="w-4 h-4 text-[#00d2ff]" />
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* 
          COMPONENT 2: FAQ / ABOUT SECTION
          (Comprehensive non-custodial DEX architecture, security, fees, liquidation, and trading rules)
        */}
        <section id="faq-section" className="w-full max-w-5xl mt-12 pt-8 border-t border-[#181d28]">
          <div className="mb-6 text-center">
            <span className="text-xs font-mono text-[#00d2ff] uppercase tracking-wider block mb-1">
              Platform Knowledge Base
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              Frequently Asked Questions
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-xl mx-auto">
              Learn how Nexora's non-custodial Hyperliquid L1 architecture guarantees zero counterparty risk and institutional execution speed.
            </p>
          </div>

          <FaqSection
            onStartTrading={() => {
              setActiveTab('register');
              window.scrollTo({ top: 120, behavior: 'smooth' });
            }}
          />
        </section>
      </main>

      {/* Standalone Minimalist Footer */}
      <footer className="border-t border-[#181d28] bg-[#07090e] py-6 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 font-mono">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#00d2ff]" />
            <span className="font-sans font-bold text-slate-300">Nexora DEX</span>
            <span>· Powered by Hyperliquid L1 Engine</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>100% Non-Custodial</span>
            <span>·</span>
            <span>Oracle Latency: 12ms</span>
            <span>·</span>
            <span>Audited &amp; Open-Source</span>
          </div>
        </div>
      </footer>

      {/* Auth Modal (if opened via button) */}
      {isModalOpen && (
        <AuthModal
          initialMode={currentModalMode}
          onClose={handleCloseModal}
          onSuccess={() => {
            handleCloseModal();
            if (onAuthenticated) {
              onAuthenticated(intendedDestination);
            }
          }}
        />
      )}
    </div>
  );
};
