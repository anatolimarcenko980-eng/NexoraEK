import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Market, Position, Order, PositionSide, MarginMode, ClosedTrade } from '../types/market';
import { INITIAL_MARKETS } from '../data/marketsData';
import { INITIAL_HISTORICAL_TRADES } from '../data/historicalTrades';
import { calculateLiquidationPrice } from '../utils/tradingMath';
import { LanguageCode, TRANSLATIONS } from '../i18n/translations';
import {
  MasterTrader,
  CopiedTraderRecord,
  MASTER_TRADERS,
  DEFAULT_USER_TRADER_PROFILE,
} from '../data/copytradingData';
import { PortfolioTransaction } from '../types/portfolio';
import { INITIAL_TRANSACTIONS, INITIAL_TOKEN_BALANCES, PORTFOLIO_CRYPTO_LIST } from '../data/portfolioData';
import { RegisteredUser } from '../types/user';

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'info' | 'warning' | 'error';
  timestamp: number;
}

export type AppTheme = 'dark' | 'light' | 'midnight';
export type CandleColorPalette = 'cyan-coral' | 'emerald-ruby';
export type LayoutDensity = 'comfortable' | 'compact';
export type FiatCurrency = 'USD' | 'EUR' | 'GBP' | 'JPY';
export type RpcNetwork = 'hyperliquid-l1' | 'arbitrum-one' | 'direct-mempool';

interface TradingContextType {
  // Appearance & Platform Settings
  theme: AppTheme;
  setTheme: (theme: AppTheme) => void;
  candleColors: CandleColorPalette;
  setCandleColors: (palette: CandleColorPalette) => void;
  layoutDensity: LayoutDensity;
  setLayoutDensity: (density: LayoutDensity) => void;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  playAudioFeedback: (type?: 'click' | 'fill' | 'alert' | 'success') => void;
  oneClickTrading: boolean;
  setOneClickTrading: (enabled: boolean) => void;
  slippageTolerance: number;
  setSlippageTolerance: (val: number) => void;
  fiatCurrency: FiatCurrency;
  setFiatCurrency: (curr: FiatCurrency) => void;
  priceFlashEnabled: boolean;
  setPriceFlashEnabled: (enabled: boolean) => void;
  autoHideBalances: boolean;
  setAutoHideBalances: (enabled: boolean) => void;
  selectedRpcNetwork: RpcNetwork;
  setSelectedRpcNetwork: (rpc: RpcNetwork) => void;
  defaultOrderLeverage: number;
  setDefaultOrderLeverage: (lev: number) => void;
  markets: Market[];
  selectedMarket: Market;
  setSelectedMarket: (market: Market) => void;
  positions: Position[];
  orders: Order[];
  closedTrades: ClosedTrade[];
  walletBalance: number;
  availableBalance: number;
  isConnected: boolean;
  walletAddress: string;
  connectWallet: () => void;
  disconnectWallet: () => void;
  faucetDeposit: (amount?: number) => void;
  resetDemoAccount: () => void;
  openPosition: (params: {
    market: Market;
    side: PositionSide;
    leverage: number;
    marginMode: MarginMode;
    marginAmount: number; // in USDC
    tpPrice?: number;
    slPrice?: number;
  }) => { success: boolean; positionId?: string; error?: string };
  closePosition: (positionId: string) => { success: boolean; realizedPnl: number };
  updateTpSl: (positionId: string, tpPrice?: number, slPrice?: number) => void;
  cancelOrder: (orderId: string) => void;
  notifications: NotificationItem[];
  dismissNotification: (id: string) => void;
  lastPriceFlash: Record<string, 'up' | 'down'>;
  toggleFavorite: (marketId: string) => void;
  favorites: string[];
  // Copytrading
  userTraderId: string;
  masterTraders: MasterTrader[];
  copiedTraders: CopiedTraderRecord[];
  copyTraderById: (traderId: string, margin: number, slPercent?: number) => { success: boolean; error?: string };
  stopCopyingTrader: (traderId: string) => void;
  toggleCopiedTraderStatus: (traderId: string) => void;
  userTraderProfile: typeof DEFAULT_USER_TRADER_PROFILE;
  toggleMasterTraderMode: () => void;
  // Portfolio
  tokenBalances: Record<string, number>;
  portfolioTransactions: PortfolioTransaction[];
  totalPortfolioValue: number;
  depositTokens: (asset: string, amount: number, network: string) => { success: boolean; error?: string };
  withdrawTokens: (asset: string, amount: number, address: string, network: string) => { success: boolean; error?: string };
  swapTokens: (fromAsset: string, toAsset: string, fromAmount: number) => { success: boolean; toAmount?: number; error?: string };
  // Language & User Account
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: string, fallback?: string) => string;
  userEmail: string;
  updateEmail: (email: string) => { success: boolean; error?: string };
  updatePassword: (oldPass: string, newPass: string, confirmPass: string) => { success: boolean; error?: string };
  // Auth & Registration
  currentUser: RegisteredUser | null;
  isRegistered: boolean;
  isLoggedIn: boolean;
  registeredUsers: RegisteredUser[];
  registerUser: (params: {
    username: string;
    fullName?: string;
    email: string;
    password?: string;
    referralCode?: string;
    authMethod?: 'email' | 'wallet' | 'google' | 'apple' | 'passkey';
    walletAddress?: string;
  }) => { success: boolean; error?: string; user?: RegisteredUser };
  loginUser: (params: { emailOrUsername: string; password?: string }) => { success: boolean; error?: string; user?: RegisteredUser };
  logoutUser: () => void;
  switchUser: (userId: string) => void;
  // Demo Trading Mode
  tradingMode: 'demo' | 'live';
  isDemoMode: boolean;
  setTradingMode: (mode: 'demo' | 'live') => void;
  toggleTradingMode: () => void;
  demoBalance: number;
  liveBalance: number;
  resetDemoBalance: (amount?: number) => void;
}

const TradingContext = createContext<TradingContextType | undefined>(undefined);

export const TradingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [markets, setMarkets] = useState<Market[]>(INITIAL_MARKETS);
  const [selectedMarketId, setSelectedMarketId] = useState<string>('BTC-USDC');

  // Live Trading Mode
  const [tradingMode, setTradingModeState] = useState<'demo' | 'live'>('live');

  const [liveBalance, setLiveBalance] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('nexora_live_balance');
      return saved ? parseFloat(saved) : 10000.00;
    } catch {
      return 10000.00;
    }
  });

  const demoBalance = liveBalance;
  const walletBalance = liveBalance;

  const setWalletBalance = useCallback((updater: number | ((prev: number) => number)) => {
    setLiveBalance(prev => {
      const val = typeof updater === 'function' ? updater(prev) : updater;
      try { localStorage.setItem('nexora_live_balance', val.toString()); } catch {}
      return val;
    });
  }, []);

  const [isConnected, setIsConnected] = useState<boolean>(true);
  const [walletAddress, setWalletAddress] = useState<string>('0x7F41...b92E');
  const [positions, setPositions] = useState<Position[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [closedTrades, setClosedTrades] = useState<ClosedTrade[]>(INITIAL_HISTORICAL_TRADES);
  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'welcome',
      title: 'Welcome to Nexora DEX',
      message: 'Connected to Hyperliquid L1. $10,000.00 test USDC ready for live position opening.',
      type: 'info',
      timestamp: Date.now(),
    }
  ]);
  const [lastPriceFlash, setLastPriceFlash] = useState<Record<string, 'up' | 'down'>>({});
  const [favorites, setFavorites] = useState<string[]>(['BTC-USDC', 'ETH-USDC', 'SOL-USDC', 'XRP-USDC', 'HYPE-USDC']);
  const [language, setLanguageState] = useState<LanguageCode>('en');

  // ================= THEME & DISPLAY SETTINGS =================
  const [theme, setThemeState] = useState<AppTheme>(() => {
    try {
      const saved = localStorage.getItem('nexora_theme');
      if (saved === 'light' || saved === 'dark' || saved === 'midnight') return saved;
      return 'dark';
    } catch {
      return 'dark';
    }
  });

  const setTheme = useCallback((newTheme: AppTheme) => {
    setThemeState(newTheme);
    try { localStorage.setItem('nexora_theme', newTheme); } catch {}
    const root = document.documentElement;
    root.classList.remove('light', 'dark', 'midnight');
    if (newTheme === 'light') {
      root.classList.add('light');
    } else if (newTheme === 'midnight') {
      root.classList.add('dark', 'midnight');
    } else {
      root.classList.add('dark');
    }
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('light', 'dark', 'midnight');
    if (theme === 'light') {
      root.classList.add('light');
    } else if (theme === 'midnight') {
      root.classList.add('dark', 'midnight');
    } else {
      root.classList.add('dark');
    }
  }, [theme]);

  // Candle colors
  const [candleColors, setCandleColorsState] = useState<CandleColorPalette>(() => {
    try {
      const saved = localStorage.getItem('nexora_candle_colors');
      if (saved === 'emerald-ruby' || saved === 'cyan-coral') return saved;
      return 'cyan-coral';
    } catch {
      return 'cyan-coral';
    }
  });
  const setCandleColors = useCallback((pal: CandleColorPalette) => {
    setCandleColorsState(pal);
    try { localStorage.setItem('nexora_candle_colors', pal); } catch {}
  }, []);

  // Layout density
  const [layoutDensity, setLayoutDensityState] = useState<LayoutDensity>(() => {
    try {
      const saved = localStorage.getItem('nexora_layout_density');
      if (saved === 'compact' || saved === 'comfortable') return saved;
      return 'comfortable';
    } catch {
      return 'comfortable';
    }
  });
  const setLayoutDensity = useCallback((density: LayoutDensity) => {
    setLayoutDensityState(density);
    try { localStorage.setItem('nexora_layout_density', density); } catch {}
  }, []);

  // Audio sound feedback
  const [soundEnabled, setSoundEnabledState] = useState<boolean>(() => {
    try {
      return localStorage.getItem('nexora_sound_enabled') !== 'false';
    } catch {
      return true;
    }
  });
  const setSoundEnabled = useCallback((en: boolean) => {
    setSoundEnabledState(en);
    try { localStorage.setItem('nexora_sound_enabled', String(en)); } catch {}
  }, []);

  const playAudioFeedback = useCallback((type: 'click' | 'fill' | 'alert' | 'success' = 'click') => {
    if (!soundEnabled) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'click') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, ctx.currentTime);
        gain.gain.setValueAtTime(0.06, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);
        osc.start();
        osc.stop(ctx.currentTime + 0.04);
      } else if (type === 'fill' || type === 'success') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(523.25, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.12);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.22);
        osc.start();
        osc.stop(ctx.currentTime + 0.22);
      } else if (type === 'alert') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(330, ctx.currentTime);
        gain.gain.setValueAtTime(0.08, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18);
        osc.start();
        osc.stop(ctx.currentTime + 0.18);
      }
    } catch {}
  }, [soundEnabled]);

  // One-click trading
  const [oneClickTrading, setOneClickTradingState] = useState<boolean>(() => {
    try {
      return localStorage.getItem('nexora_one_click_trading') === 'true';
    } catch {
      return false;
    }
  });
  const setOneClickTrading = useCallback((en: boolean) => {
    setOneClickTradingState(en);
    try { localStorage.setItem('nexora_one_click_trading', String(en)); } catch {}
  }, []);

  // Slippage tolerance
  const [slippageTolerance, setSlippageToleranceState] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('nexora_slippage');
      return saved ? parseFloat(saved) : 0.5;
    } catch {
      return 0.5;
    }
  });
  const setSlippageTolerance = useCallback((val: number) => {
    setSlippageToleranceState(val);
    try { localStorage.setItem('nexora_slippage', String(val)); } catch {}
  }, []);

  // Fiat currency
  const [fiatCurrency, setFiatCurrencyState] = useState<FiatCurrency>(() => {
    try {
      const saved = localStorage.getItem('nexora_currency');
      if (saved === 'EUR' || saved === 'GBP' || saved === 'JPY' || saved === 'USD') return saved;
      return 'USD';
    } catch {
      return 'USD';
    }
  });
  const setFiatCurrency = useCallback((curr: FiatCurrency) => {
    setFiatCurrencyState(curr);
    try { localStorage.setItem('nexora_currency', curr); } catch {}
  }, []);

  // Price Flash Enabled
  const [priceFlashEnabled, setPriceFlashEnabledState] = useState<boolean>(() => {
    try {
      return localStorage.getItem('nexora_price_flash') !== 'false';
    } catch {
      return true;
    }
  });
  const setPriceFlashEnabled = useCallback((en: boolean) => {
    setPriceFlashEnabledState(en);
    try { localStorage.setItem('nexora_price_flash', String(en)); } catch {}
  }, []);

  // Auto Hide Balances
  const [autoHideBalances, setAutoHideBalancesState] = useState<boolean>(() => {
    try {
      return localStorage.getItem('nexora_auto_hide_balances') === 'true';
    } catch {
      return false;
    }
  });
  const setAutoHideBalances = useCallback((en: boolean) => {
    setAutoHideBalancesState(en);
    try { localStorage.setItem('nexora_auto_hide_balances', String(en)); } catch {}
  }, []);

  // Network RPC
  const [selectedRpcNetwork, setSelectedRpcNetworkState] = useState<RpcNetwork>(() => {
    try {
      const saved = localStorage.getItem('nexora_rpc_network');
      if (saved === 'arbitrum-one' || saved === 'direct-mempool' || saved === 'hyperliquid-l1') return saved;
      return 'hyperliquid-l1';
    } catch {
      return 'hyperliquid-l1';
    }
  });
  const setSelectedRpcNetwork = useCallback((net: RpcNetwork) => {
    setSelectedRpcNetworkState(net);
    try { localStorage.setItem('nexora_rpc_network', net); } catch {}
  }, []);

  // Default Order Leverage
  const [defaultOrderLeverage, setDefaultOrderLeverageState] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('nexora_default_leverage');
      return saved ? parseInt(saved, 10) : 10;
    } catch {
      return 10;
    }
  });
  const setDefaultOrderLeverage = useCallback((lev: number) => {
    setDefaultOrderLeverageState(lev);
    try { localStorage.setItem('nexora_default_leverage', String(lev)); } catch {}
  }, []);

  // Registered User & Account state
  const DEFAULT_USER: RegisteredUser = {
    id: 'NX-94718',
    username: 'AnatoliM',
    email: 'anatolimarcenko980@gmail.com',
    registeredAt: '2026-09-15',
    vipTier: 'VIP 1',
    makerFeeDiscount: 100, // 0% maker fee
    takerFeeRate: 0.02,
    authMethod: 'email',
    walletAddress: '0x7F41...b92E',
    isEmailVerified: true,
    twoFactorEnabled: false,
    myReferralCode: 'NX-94718',
  };

  const [registeredUsers, setRegisteredUsers] = useState<RegisteredUser[]>(() => {
    try {
      const saved = localStorage.getItem('nexora_registered_users');
      return saved ? JSON.parse(saved) : [DEFAULT_USER];
    } catch {
      return [DEFAULT_USER];
    }
  });

  const [currentUser, setCurrentUser] = useState<RegisteredUser | null>(() => {
    try {
      const savedLoggedIn = localStorage.getItem('nexora_is_logged_in');
      if (savedLoggedIn === 'false') return null;
      const saved = localStorage.getItem('nexora_current_user');
      if (savedLoggedIn === 'true' && saved) return JSON.parse(saved);
      return null;
    } catch {
      return null;
    }
  });

  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('nexora_is_logged_in');
      return saved !== null ? saved === 'true' : false;
    } catch {
      return false;
    }
  });

  const [userEmail, setUserEmail] = useState<string>(() => currentUser?.email || 'anatolimarcenko980@gmail.com');

  // Copytrading state
  const [masterTraders, setMasterTraders] = useState<MasterTrader[]>(MASTER_TRADERS);
  const [userTraderProfile, setUserTraderProfile] = useState(DEFAULT_USER_TRADER_PROFILE);
  const [copiedTraders, setCopiedTraders] = useState<CopiedTraderRecord[]>([
    {
      traderId: 'NX-90421',
      traderName: 'Elena Vance',
      traderHandle: '@CryptoValkyrie',
      allocatedMargin: 500,
      stopLossPercent: 15,
      copiedAt: Date.now() - 3600 * 24 * 3 * 1000,
      status: 'active',
      copiedPnl: 142.50,
      activeCopiedTradesCount: 4,
    }
  ]);

  // Portfolio state
  const [tokenBalances, setTokenBalances] = useState<Record<string, number>>(INITIAL_TOKEN_BALANCES);


  const [portfolioTransactions, setPortfolioTransactions] = useState<PortfolioTransaction[]>(INITIAL_TRANSACTIONS);

  // Sync tokenBalances.USDC with walletBalance
  useEffect(() => {
    setTokenBalances(prev => {
      if (prev.USDC !== walletBalance) {
        return { ...prev, USDC: walletBalance };
      }
      return prev;
    });
  }, [walletBalance]);
  useEffect(() => {
    async function fetchLiveTicker() {
      try {
        const res = await fetch('https://api.binance.com/api/v3/ticker/24hr');
        if (!res.ok) return;
        const data = await res.json();
        
        const priceMap: Record<string, { price: number; change24h: number; high: number; low: number; volume: number }> = {};
        for (const item of data) {
          if (item.symbol.endsWith('USDT') || item.symbol.endsWith('USDC')) {
            const base = item.symbol.replace(/USDT|USDC$/, '');
            priceMap[base] = {
              price: parseFloat(item.lastPrice),
              change24h: parseFloat(item.priceChangePercent),
              high: parseFloat(item.highPrice),
              low: parseFloat(item.lowPrice),
              volume: parseFloat(item.quoteVolume),
            };
          }
        }

        setMarkets(prev => prev.map(m => {
          const live = priceMap[m.baseAsset];
          if (live && live.price > 0) {
            return {
              ...m,
              price: live.price,
              change24h: live.change24h,
              high24h: live.high,
              low24h: live.low,
              volume24h: Math.max(m.volume24h, live.volume),
            };
          }
          return m;
        }));
      } catch {
        // Quiet fallback to realistic default prices
      }
    }

    fetchLiveTicker();
  }, []);

  // Compute selectedMarket object
  const selectedMarket = markets.find(m => m.id === selectedMarketId) || markets[0];

  // Calculate margin reserved in positions
  const marginInUse = positions.reduce((sum, p) => sum + p.margin, 0);
  const availableBalance = Math.max(0, walletBalance - marginInUse);

  // Live price fluctuation engine (ticking every 1.5s)
  useEffect(() => {
    const timer = setInterval(() => {
      setMarkets(prevMarkets => {
        const flashes: Record<string, 'up' | 'down'> = {};
        const updated = prevMarkets.map(market => {
          // 40% chance of updating any given market, but always update selectedMarket
          if (market.id !== selectedMarketId && Math.random() > 0.4) {
            return market;
          }

          const volatility = 0.0006 * (Math.random() * 1.5);
          const direction = Math.random() > 0.49 ? 1 : -1;
          const delta = market.price * volatility * direction;
          const newPrice = Math.max(0.00001, market.price + delta);

          flashes[market.id] = delta >= 0 ? 'up' : 'down';

          return {
            ...market,
            price: newPrice,
            high24h: Math.max(market.high24h, newPrice),
            low24h: Math.min(market.low24h, newPrice),
          };
        });

        setLastPriceFlash(flashes);
        return updated;
      });
    }, 1800);

    return () => clearInterval(timer);
  }, [selectedMarketId]);

  // Recalculate dynamic PnL for active positions whenever markets tick
  useEffect(() => {
    setPositions(prevPositions => {
      if (prevPositions.length === 0) return prevPositions;

      return prevPositions.map(pos => {
        const currentMarket = markets.find(m => m.id === pos.marketId);
        if (!currentMarket) return pos;

        const markPrice = currentMarket.price;
        let unrealizedPnl = 0;
        let unrealizedPnlPercent = 0;

        if (pos.side === 'long') {
          unrealizedPnl = (markPrice - pos.entryPrice) * pos.size;
          unrealizedPnlPercent = ((markPrice - pos.entryPrice) / pos.entryPrice) * pos.leverage * 100;
        } else {
          unrealizedPnl = (pos.entryPrice - markPrice) * pos.size;
          unrealizedPnlPercent = ((pos.entryPrice - markPrice) / pos.entryPrice) * pos.leverage * 100;
        }

        return {
          ...pos,
          markPrice,
          unrealizedPnl,
          unrealizedPnlPercent,
        };
      });
    });
  }, [markets]);

  const connectWallet = useCallback(() => {
    setIsConnected(true);
    setWalletAddress('0x7F41...b92E');
    setNotifications(prev => [
      {
        id: 'conn-' + Date.now(),
        title: 'Wallet Connected',
        message: 'Privy Smart Wallet connected: 0x7F41...b92E',
        type: 'success',
        timestamp: Date.now(),
      },
      ...prev,
    ]);
  }, []);

  const disconnectWallet = useCallback(() => {
    setIsConnected(false);
  }, []);

  const setTradingMode = useCallback((mode: 'demo' | 'live') => {
    // Pure Live mode
    setTradingModeState('live');
  }, []);

  const toggleTradingMode = useCallback(() => {
    // Pure Live mode
    setTradingModeState('live');
  }, []);

  const resetDemoBalance = useCallback((customAmount: number = 10000.00) => {
    setLiveBalance(customAmount);
  }, []);

  const resetDemoAccount = useCallback(() => {
    setLiveBalance(10000.00);
  }, []);

  const faucetDeposit = useCallback((amount: number = 5000) => {
    setWalletBalance(prev => prev + amount);
    setNotifications(prev => [
      {
        id: 'faucet-' + Date.now(),
        title: 'Collateral Deposited',
        message: `+${amount.toLocaleString()} USDC added to your live balance.`,
        type: 'success',
        timestamp: Date.now(),
      },
      ...prev,
    ]);
  }, [setWalletBalance]);

  const toggleFavorite = useCallback((marketId: string) => {
    setFavorites(prev => 
      prev.includes(marketId) ? prev.filter(id => id !== marketId) : [...prev, marketId]
    );
  }, []);

  // Open a new trading position
  const openPosition = useCallback(({
    market,
    side,
    leverage,
    marginMode,
    marginAmount,
    tpPrice,
    slPrice,
  }: {
    market: Market;
    side: PositionSide;
    leverage: number;
    marginMode: MarginMode;
    marginAmount: number;
    tpPrice?: number;
    slPrice?: number;
  }) => {
    if (marginAmount <= 0) {
      return { success: false, error: 'Margin amount must be greater than 0' };
    }
    if (marginAmount > availableBalance) {
      return { success: false, error: 'Insufficient available margin' };
    }

    const notionalUsdc = marginAmount * leverage;
    const entryPrice = market.price;
    const size = notionalUsdc / entryPrice;
    const liqPrice = calculateLiquidationPrice(entryPrice, side, leverage);

    const newPosition: Position = {
      id: 'pos-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
      marketId: market.id,
      symbol: market.symbol,
      baseAsset: market.baseAsset,
      side,
      leverage,
      marginMode,
      size,
      sizeUsdc: notionalUsdc,
      entryPrice,
      markPrice: entryPrice,
      liqPrice,
      margin: marginAmount,
      tpPrice,
      slPrice,
      unrealizedPnl: 0,
      unrealizedPnlPercent: 0,
      createdAt: Date.now(),
      isDemo: false,
    };

    setPositions(prev => [newPosition, ...prev]);

    // Send toast notification
    setNotifications(prev => [
      {
        id: 'pos-open-' + Date.now(),
        title: `${side.toUpperCase()} Position Opened`,
        message: `${leverage}x ${market.symbol} | Size: $${notionalUsdc.toLocaleString(undefined, { maximumFractionDigits: 2 })} at $${entryPrice.toLocaleString()}`,
        type: 'success',
        timestamp: Date.now(),
      },
      ...prev,
    ]);

    return { success: true, positionId: newPosition.id };
  }, [availableBalance]);

  // Close an active position
  const closePosition = useCallback((positionId: string) => {
    const position = positions.find(p => p.id === positionId);
    if (!position) return { success: false, realizedPnl: 0 };

    const realizedPnl = position.unrealizedPnl;
    const netReturn = position.margin + realizedPnl;

    setWalletBalance(prev => Math.max(0, prev + realizedPnl));
    setPositions(prev => prev.filter(p => p.id !== positionId));

    // Record into closed trades history for the Profit Calendar
    const now = new Date();
    const dateString = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const newClosedTrade: ClosedTrade = {
      id: 'trade-' + Date.now(),
      marketId: position.marketId,
      symbol: position.symbol,
      side: position.side,
      leverage: position.leverage,
      entryPrice: position.entryPrice,
      exitPrice: position.markPrice,
      size: position.size,
      sizeUsdc: position.sizeUsdc,
      pnl: realizedPnl,
      pnlPercent: position.unrealizedPnlPercent,
      closedAt: Date.now(),
      dateString,
      isDemo: false,
    };

    setClosedTrades(prev => [newClosedTrade, ...prev]);

    setNotifications(prev => [
      {
        id: 'pos-close-' + Date.now(),
        title: `Closed ${position.side.toUpperCase()} ${position.symbol}`,
        message: `Realized PnL: ${realizedPnl >= 0 ? '+' : ''}$${realizedPnl.toFixed(2)} (${position.unrealizedPnlPercent >= 0 ? '+' : ''}${position.unrealizedPnlPercent.toFixed(2)}%)`,
        type: realizedPnl >= 0 ? 'success' : 'warning',
        timestamp: Date.now(),
      },
      ...prev,
    ]);

    return { success: true, realizedPnl };
  }, [positions]);

  const updateTpSl = useCallback((positionId: string, tpPrice?: number, slPrice?: number) => {
    setPositions(prev => prev.map(p => {
      if (p.id === positionId) {
        return { ...p, tpPrice, slPrice };
      }
      return p;
    }));

    setNotifications(prev => [
      {
        id: 'tpsl-' + Date.now(),
        title: 'TP/SL Updated',
        message: `Updated trigger orders: TP ${tpPrice ? '$' + tpPrice : 'None'} | SL ${slPrice ? '$' + slPrice : 'None'}`,
        type: 'info',
        timestamp: Date.now(),
      },
      ...prev,
    ]);
  }, []);

  const cancelOrder = useCallback((orderId: string) => {
    setOrders(prev => prev.filter(o => o.id !== orderId));
  }, []);

  const dismissNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const setLanguage = useCallback((lang: LanguageCode) => {
    setLanguageState(lang);
  }, []);

  const t = useCallback((key: string, fallback?: string): string => {
    return TRANSLATIONS[language]?.[key] || fallback || TRANSLATIONS['en']?.[key] || key;
  }, [language]);

  const updateEmail = useCallback((newEmail: string) => {
    const trimmed = newEmail.trim().toLowerCase();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmed)) {
      return { success: false, error: t('invalidEmail') };
    }
    setUserEmail(trimmed);
    setNotifications(prev => [
      {
        id: 'email-' + Date.now(),
        title: t('emailUpdated'),
        message: `${t('currentEmail')}: ${trimmed}`,
        type: 'success',
        timestamp: Date.now(),
      },
      ...prev,
    ]);
    return { success: true };
  }, [t]);

  const updatePassword = useCallback((oldPass: string, newPass: string, confirmPass: string) => {
    if (newPass.length < 6) {
      return { success: false, error: t('passwordTooShort') };
    }
    if (newPass !== confirmPass) {
      return { success: false, error: t('passwordMismatch') };
    }
    setNotifications(prev => [
      {
        id: 'pwd-' + Date.now(),
        title: t('passwordUpdated'),
        message: 'Security credentials have been updated for your account.',
        type: 'success',
        timestamp: Date.now(),
      },
      ...prev,
    ]);
    return { success: true };
  }, [t]);

  // Registration & User Auth methods
  const registerUser = useCallback((params: {
    username: string;
    fullName?: string;
    email: string;
    password?: string;
    referralCode?: string;
    authMethod?: 'email' | 'wallet' | 'google' | 'apple' | 'passkey';
    walletAddress?: string;
  }) => {
    const cleanUsername = params.username.trim();
    const cleanEmail = params.email.trim().toLowerCase();

    // Check existing username
    if (registeredUsers.some(u => u.username.toLowerCase() === cleanUsername.toLowerCase())) {
      return { success: false, error: 'Username is already taken. Please choose another.' };
    }

    // Check existing email
    if (registeredUsers.some(u => u.email.toLowerCase() === cleanEmail)) {
      return { success: false, error: 'An account with this email already exists. Please sign in.' };
    }

    const newId = 'NX-' + Math.floor(10000 + Math.random() * 90000);
    const hasVipReferral = params.referralCode && (params.referralCode.toUpperCase() === 'NX-VIP' || params.referralCode.toUpperCase().startsWith('NX-'));
    const wallet = params.walletAddress || `0x${Math.random().toString(16).substring(2, 6).toUpperCase()}...${Math.random().toString(16).substring(2, 6).toUpperCase()}`;

    const newUser: RegisteredUser = {
      id: newId,
      username: cleanUsername,
      fullName: params.fullName?.trim() || cleanUsername,
      email: cleanEmail,
      password: params.password,
      registeredAt: new Date().toISOString().split('T')[0],
      vipTier: hasVipReferral ? 'VIP 2' : 'VIP 1',
      makerFeeDiscount: 100, // 0% maker fee
      takerFeeRate: hasVipReferral ? 0.015 : 0.02,
      authMethod: params.authMethod || 'email',
      walletAddress: wallet,
      isEmailVerified: params.authMethod === 'wallet' || params.authMethod === 'google' || params.authMethod === 'apple',
      twoFactorEnabled: false,
      referralCodeUsed: params.referralCode,
      myReferralCode: newId,
    };

    const updated = [newUser, ...registeredUsers];
    setRegisteredUsers(updated);
    setCurrentUser(newUser);
    setIsLoggedIn(true);
    setUserEmail(cleanEmail);
    setWalletAddress(wallet);
    setIsConnected(true);
    setWalletBalance(10000.00);

    try {
      localStorage.setItem('nexora_registered_users', JSON.stringify(updated));
      localStorage.setItem('nexora_current_user', JSON.stringify(newUser));
      localStorage.setItem('nexora_is_logged_in', 'true');
    } catch (e) {
      console.warn('Could not persist to localStorage', e);
    }

    setNotifications(prev => [
      {
        id: 'reg-' + Date.now(),
        title: 'Registration Successful!',
        message: `Welcome @${cleanUsername}! Account ${newId} created with ${newUser.vipTier} (0% Maker Fees) and $10,000.00 live USDC.`,
        type: 'success',
        timestamp: Date.now(),
      },
      ...prev,
    ]);

    return { success: true, user: newUser };
  }, [registeredUsers]);

  const loginUser = useCallback((params: { emailOrUsername: string; password?: string }) => {
    const ident = params.emailOrUsername.trim().toLowerCase();
    const found = registeredUsers.find(
      u => u.email.toLowerCase() === ident || u.username.toLowerCase() === ident
    );

    if (!found) {
      if (ident.includes('@')) {
        return registerUser({
          username: ident.split('@')[0],
          email: ident,
          password: params.password,
        });
      }
      return { success: false, error: 'No account found with this email or username. Please create an account.' };
    }

    if (found.password && params.password && found.password !== params.password) {
      return { success: false, error: 'Incorrect password. Please try again.' };
    }

    setCurrentUser(found);
    setIsLoggedIn(true);
    setUserEmail(found.email);
    setWalletAddress(found.walletAddress);
    setIsConnected(true);

    try {
      localStorage.setItem('nexora_current_user', JSON.stringify(found));
      localStorage.setItem('nexora_is_logged_in', 'true');
    } catch (e) {
      console.warn('Could not persist to localStorage', e);
    }

    setNotifications(prev => [
      {
        id: 'login-' + Date.now(),
        title: 'Signed In',
        message: `Welcome back, ${found.username} (${found.id})!`,
        type: 'success',
        timestamp: Date.now(),
      },
      ...prev,
    ]);

    return { success: true, user: found };
  }, [registeredUsers, registerUser]);

  const logoutUser = useCallback(() => {
    setIsLoggedIn(false);
    try {
      localStorage.setItem('nexora_is_logged_in', 'false');
    } catch (e) {
      console.warn('Could not persist to localStorage', e);
    }

    setNotifications(prev => [
      {
        id: 'logout-' + Date.now(),
        title: 'Logged Out',
        message: 'You have been disconnected from the trading terminal.',
        type: 'info',
        timestamp: Date.now(),
      },
      ...prev,
    ]);
  }, []);

  const switchUser = useCallback((userId: string) => {
    const found = registeredUsers.find(u => u.id === userId);
    if (found) {
      setCurrentUser(found);
      setIsLoggedIn(true);
      setUserEmail(found.email);
      setWalletAddress(found.walletAddress);
      setIsConnected(true);
      try {
        localStorage.setItem('nexora_current_user', JSON.stringify(found));
        localStorage.setItem('nexora_is_logged_in', 'true');
      } catch (e) {}
    }
  }, [registeredUsers]);

  // Copytrading Methods
  const copyTraderById = useCallback((traderId: string, margin: number, slPercent = 15) => {
    const cleanId = traderId.trim().toUpperCase();
    if (!cleanId) {
      return { success: false, error: 'Please enter a valid Trader ID (e.g. NX-90421).' };
    }
    if (cleanId === userTraderProfile.id) {
      return { success: false, error: 'You cannot copy your own Trader ID.' };
    }
    if (margin <= 0) {
      return { success: false, error: 'Allocation margin must be greater than 0.' };
    }
    if (margin > availableBalance) {
      return { success: false, error: `Insufficient available balance ($${availableBalance.toFixed(2)} USDC available).` };
    }
    if (copiedTraders.some(c => c.traderId === cleanId)) {
      return { success: false, error: `You are already copying Trader ${cleanId}.` };
    }

    const existing = masterTraders.find(t => t.id === cleanId);
    const traderName = existing ? existing.name : `Trader ${cleanId}`;
    const traderHandle = existing ? existing.handle : `@trader_${cleanId.toLowerCase().replace('-', '')}`;

    const newRecord: CopiedTraderRecord = {
      traderId: cleanId,
      traderName,
      traderHandle,
      allocatedMargin: margin,
      stopLossPercent: slPercent,
      copiedAt: Date.now(),
      status: 'active',
      copiedPnl: 0,
      activeCopiedTradesCount: existing ? existing.activeDeals.length : 2,
    };

    setCopiedTraders(prev => [newRecord, ...prev]);

    if (existing) {
      setMasterTraders(prev => prev.map(m => m.id === cleanId ? { ...m, copiersCount: m.copiersCount + 1 } : m));
    }

    setNotifications(prev => [
      {
        id: 'copy-' + Date.now(),
        title: 'Copy Trading Started',
        message: `Successfully mirrored ${traderName} (${cleanId}) with $${margin.toFixed(2)} USDC allocation.`,
        type: 'success',
        timestamp: Date.now(),
      },
      ...prev,
    ]);

    return { success: true };
  }, [availableBalance, copiedTraders, masterTraders, userTraderProfile.id]);

  const stopCopyingTrader = useCallback((traderId: string) => {
    setCopiedTraders(prev => prev.filter(c => c.traderId !== traderId));
    setNotifications(prev => [
      {
        id: 'stop-copy-' + Date.now(),
        title: 'Stopped Copying',
        message: `Released copied position margin back to available balance for Trader ${traderId}.`,
        type: 'info',
        timestamp: Date.now(),
      },
      ...prev,
    ]);
  }, []);

  const toggleCopiedTraderStatus = useCallback((traderId: string) => {
    setCopiedTraders(prev => prev.map(c => {
      if (c.traderId === traderId) {
        const nextStatus = c.status === 'active' ? 'paused' : 'active';
        return { ...c, status: nextStatus };
      }
      return c;
    }));
  }, []);

  const toggleMasterTraderMode = useCallback(() => {
    setUserTraderProfile(prev => {
      const nextEnabled = !prev.isMasterTraderEnabled;
      setNotifications(n => [
        {
          id: 'master-' + Date.now(),
          title: nextEnabled ? 'Master Trader Mode Enabled' : 'Master Trader Mode Disabled',
          message: nextEnabled
            ? `Your public Trader ID (${prev.id}) is now open for followers. 10% profit-sharing fee enabled.`
            : 'Copy trading requests for your ID are now paused.',
          type: nextEnabled ? 'success' : 'info',
          timestamp: Date.now(),
        },
        ...n,
      ]);
      return { ...prev, isMasterTraderEnabled: nextEnabled };
    });
  }, []);

  // Portfolio value computation across all crypto holdings
  const totalPortfolioValue = React.useMemo(() => {
    return Object.entries(tokenBalances).reduce((total, [sym, balance]) => {
      if (!balance || balance <= 0) return total;
      if (sym === 'USDC' || sym === 'USDT') return total + balance;
      const m = markets.find(item => item.baseAsset === sym || item.symbol === `${sym}-USDC` || item.symbol === `${sym}-USDT`);
      const defaultMeta = PORTFOLIO_CRYPTO_LIST.find(c => c.symbol === sym);
      const price = m ? m.price : (defaultMeta ? defaultMeta.defaultPrice : 1.0);
      return total + (balance * price);
    }, 0);
  }, [tokenBalances, markets]);

  // Deposit tokens
  const depositTokens = useCallback((asset: string, amount: number, network: string) => {
    if (amount <= 0) {
      return { success: false, error: 'Deposit amount must be greater than zero.' };
    }
    setTokenBalances(prev => ({
      ...prev,
      [asset]: (prev[asset] || 0) + amount,
    }));
    if (asset === 'USDC') {
      setWalletBalance(prev => prev + amount);
    }

    const tx: PortfolioTransaction = {
      id: 'tx-dep-' + Date.now(),
      type: 'deposit',
      title: `Deposit ${asset}`,
      description: `Deposited ${amount} ${asset} via ${network}`,
      asset,
      amount,
      usdValue: amount,
      status: 'completed',
      txHash: '0x' + Math.random().toString(16).substring(2, 10) + '...' + Math.random().toString(16).substring(2, 6),
      timestamp: Date.now(),
      details: { network }
    };
    setPortfolioTransactions(prev => [tx, ...prev]);

    setNotifications(prev => [
      {
        id: 'dep-' + Date.now(),
        title: 'Deposit Confirmed',
        message: `+${amount.toLocaleString()} ${asset} credited via ${network}.`,
        type: 'success',
        timestamp: Date.now(),
      },
      ...prev,
    ]);
    return { success: true };
  }, []);

  // Withdraw tokens
  const withdrawTokens = useCallback((asset: string, amount: number, address: string, network: string) => {
    if (!address.trim()) {
      return { success: false, error: 'Please enter a valid recipient address.' };
    }
    const curBal = tokenBalances[asset] || 0;
    if (amount <= 0 || amount > curBal) {
      return { success: false, error: `Insufficient ${asset} balance (Available: ${curBal} ${asset}).` };
    }
    if (asset === 'USDC' && amount > availableBalance) {
      return { success: false, error: `Cannot withdraw margin locked in active positions ($${availableBalance.toFixed(2)} USDC available).` };
    }

    setTokenBalances(prev => ({
      ...prev,
      [asset]: Math.max(0, (prev[asset] || 0) - amount),
    }));
    if (asset === 'USDC') {
      setWalletBalance(prev => Math.max(0, prev - amount));
    }

    const tx: PortfolioTransaction = {
      id: 'tx-wd-' + Date.now(),
      type: 'withdraw',
      title: `Withdraw ${asset}`,
      description: `Transferred ${amount} ${asset} to ${address.slice(0, 6)}...${address.slice(-4)} via ${network}`,
      asset,
      amount,
      usdValue: amount,
      status: 'completed',
      txHash: '0x' + Math.random().toString(16).substring(2, 10) + '...' + Math.random().toString(16).substring(2, 6),
      timestamp: Date.now(),
      details: { destinationAddress: address, network }
    };
    setPortfolioTransactions(prev => [tx, ...prev]);

    setNotifications(prev => [
      {
        id: 'wd-' + Date.now(),
        title: 'Withdrawal Broadcasted',
        message: `Successfully transferred ${amount} ${asset} to ${address.slice(0, 6)}...${address.slice(-4)}.`,
        type: 'info',
        timestamp: Date.now(),
      },
      ...prev,
    ]);
    return { success: true };
  }, [tokenBalances, availableBalance]);

  // Swap tokens with 0 commission bonus
  const swapTokens = useCallback((fromAsset: string, toAsset: string, fromAmount: number) => {
    if (fromAsset === toAsset) {
      return { success: false, error: 'Cannot swap the same asset.' };
    }
    const curFromBal = tokenBalances[fromAsset] || 0;
    if (fromAmount <= 0 || fromAmount > curFromBal) {
      return { success: false, error: `Insufficient ${fromAsset} balance (Available: ${curFromBal}).` };
    }
    if (fromAsset === 'USDC' && fromAmount > availableBalance) {
      return { success: false, error: `Cannot swap margin locked in positions ($${availableBalance.toFixed(2)} available).` };
    }

    const getAssetPrice = (sym: string): number => {
      if (sym === 'USDC' || sym === 'USDT') return 1.0;
      const found = markets.find(m => m.baseAsset === sym || m.symbol === `${sym}-USDC` || m.symbol === `${sym}-USDT`);
      return found ? found.price : 1.0;
    };

    const fromPrice = getAssetPrice(fromAsset);
    const toPrice = getAssetPrice(toAsset);
    const fromValueUsd = fromAmount * fromPrice;
    const toAmount = fromValueUsd / toPrice;

    setTokenBalances(prev => ({
      ...prev,
      [fromAsset]: Math.max(0, (prev[fromAsset] || 0) - fromAmount),
      [toAsset]: (prev[toAsset] || 0) + toAmount,
    }));

    if (fromAsset === 'USDC') {
      setWalletBalance(prev => Math.max(0, prev - fromAmount));
    } else if (toAsset === 'USDC') {
      setWalletBalance(prev => prev + toAmount);
    }

    const tx: PortfolioTransaction = {
      id: 'tx-swap-' + Date.now(),
      type: 'swap',
      title: `Swap: ${fromAsset} → ${toAsset}`,
      description: `Swapped ${fromAmount} ${fromAsset} to ${toAmount.toFixed(4)} ${toAsset}`,
      asset: toAsset,
      amount: toAmount,
      usdValue: fromValueUsd,
      status: 'completed',
      txHash: '0x' + Math.random().toString(16).substring(2, 10) + '...swap',
      timestamp: Date.now(),
      details: {
        fromAsset,
        toAsset,
        fromAmount,
        toAmount,
      }
    };
    setPortfolioTransactions(prev => [tx, ...prev]);

    setNotifications(prev => [
      {
        id: 'swap-' + Date.now(),
        title: 'Swap Completed',
        message: `Swapped ${fromAmount} ${fromAsset} to ${toAmount.toFixed(4)} ${toAsset}.`,
        type: 'success',
        timestamp: Date.now(),
      },
      ...prev,
    ]);

    return { success: true, toAmount };
  }, [tokenBalances, availableBalance, markets]);

  return (
    <TradingContext.Provider
      value={{
        theme,
        setTheme,
        candleColors,
        setCandleColors,
        layoutDensity,
        setLayoutDensity,
        soundEnabled,
        setSoundEnabled,
        playAudioFeedback,
        oneClickTrading,
        setOneClickTrading,
        slippageTolerance,
        setSlippageTolerance,
        fiatCurrency,
        setFiatCurrency,
        priceFlashEnabled,
        setPriceFlashEnabled,
        autoHideBalances,
        setAutoHideBalances,
        selectedRpcNetwork,
        setSelectedRpcNetwork,
        defaultOrderLeverage,
        setDefaultOrderLeverage,
        markets,
        selectedMarket,
        setSelectedMarket: (m) => setSelectedMarketId(m.id),
        positions,
        orders,
        closedTrades,
        walletBalance,
        availableBalance,
        isConnected,
        walletAddress,
        connectWallet,
        disconnectWallet,
        faucetDeposit,
        resetDemoAccount,
        openPosition,
        closePosition,
        updateTpSl,
        cancelOrder,
        notifications,
        dismissNotification,
        lastPriceFlash,
        toggleFavorite,
        favorites,
        // Copytrading
        userTraderId: userTraderProfile.id,
        masterTraders,
        copiedTraders,
        copyTraderById,
        stopCopyingTrader,
        toggleCopiedTraderStatus,
        userTraderProfile,
        toggleMasterTraderMode,
        // Portfolio
        tokenBalances,
        portfolioTransactions,
        totalPortfolioValue,
        depositTokens,
        withdrawTokens,
        swapTokens,
        // Language & Account
        language,
        setLanguage,
        t,
        userEmail,
        updateEmail,
        updatePassword,
        // Auth & Registration
        currentUser,
        isRegistered: Boolean(currentUser),
        isLoggedIn,
        registeredUsers,
        registerUser,
        loginUser,
        logoutUser,
        switchUser,
        // Live Trading Mode
        tradingMode,
        isDemoMode: false,
        setTradingMode,
        toggleTradingMode,
        demoBalance,
        liveBalance,
        resetDemoBalance,
      }}
    >
      {children}
    </TradingContext.Provider>
  );
};

export const useTrading = () => {
  const context = useContext(TradingContext);
  if (!context) {
    throw new Error('useTrading must be used within a TradingProvider');
  }
  return context;
};
